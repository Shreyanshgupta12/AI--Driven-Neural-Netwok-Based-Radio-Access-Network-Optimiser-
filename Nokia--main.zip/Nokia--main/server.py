"""
FastAPI Server for Nokia AI-RAN Optimization Platform
Exposes REST APIs for simulation control, scenario injection, real-time telemetry,
benchmarking, and 2D topology visualizers.
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Optional

from core.orchestrator import AIRANOrchestrator
from core.benchmark import BenchmarkEngine

app = FastAPI(
    title="Nokia AI-RAN Optimization Platform",
    description="Real-time AI Algorithms at Radio Silicon & Machine Learning Network Intelligence",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global orchestrator instance
orchestrator = AIRANOrchestrator(mode="AI_ENABLED")


class ScenarioRequest(BaseModel):
    scenario: str  # "normal", "rush_hour", "stadium_surge", "night_lull", "rain_fade"


class ModeRequest(BaseModel):
    mode: str  # "AI_ENABLED", "LEGACY_BASELINE"


@app.get("/api/status")
def get_status():
    return {
        "status": "online",
        "platform": "Nokia AI-RAN Engine",
        "mode": orchestrator.mode,
        "current_scenario": orchestrator.sim.current_scenario,
        "simulation_hour": round(orchestrator.sim.simulation_hour, 2),
        "total_steps": orchestrator.sim.time_step,
        "cells": list(orchestrator.sim.cells.keys())
    }


@app.post("/api/step")
def step_simulation():
    """Advances simulation by 1 step (15 mins) and returns state & AI decisions."""
    result = orchestrator.run_step()
    return result


@app.post("/api/scenario")
def set_scenario(req: ScenarioRequest):
    """Changes current operational scenario."""
    valid_scenarios = ["normal", "rush_hour", "stadium_surge", "night_lull", "rain_fade"]
    if req.scenario not in valid_scenarios:
        raise HTTPException(status_code=400, detail=f"Invalid scenario. Choose from {valid_scenarios}")
    orchestrator.set_scenario(req.scenario)
    return {"message": f"Scenario set to {req.scenario}", "scenario": req.scenario}


@app.post("/api/mode")
def set_mode(req: ModeRequest):
    """Toggles between AI-Native RAN and Legacy Rule-Based RAN."""
    if req.mode not in ["AI_ENABLED", "LEGACY_BASELINE"]:
        raise HTTPException(status_code=400, detail="Mode must be 'AI_ENABLED' or 'LEGACY_BASELINE'")
    orchestrator.mode = req.mode
    return {"message": f"Orchestrator mode set to {req.mode}", "mode": req.mode}


@app.post("/api/reset")
def reset_simulation():
    """Resets simulator to initial 08:00 AM state."""
    orchestrator.reset()
    return {"message": "Simulation reset successfully."}


@app.get("/api/benchmark")
def run_benchmark(steps: int = 48):
    """Runs dual-track 24-hour benchmark (Legacy vs AI-RAN) and returns KPIs."""
    engine = BenchmarkEngine(steps=steps)
    report = engine.run_benchmark()
    return report


@app.get("/api/topology")
def get_topology():
    """Returns cell site coordinates, beam angles, and connected UEs for 2D map."""
    cells_data = []
    for cid, cell in orchestrator.sim.cells.items():
        ues = []
        for uid, ue in cell.connected_ues.items():
            ues.append({
                "id": uid,
                "x": round(ue.x, 1),
                "y": round(ue.y, 1),
                "type": ue.traffic_type.value,
                "cqi": ue.cqi,
                "sinr_db": ue.sinr_db,
                "rate_mbps": round(ue.served_throughput_mbps, 1),
                "delay_ms": round(ue.queue_delay_ms, 1),
                "prbs": ue.assigned_prbs,
                "handover_cand": ue.handover_candidate
            })
        cells_data.append({
            "id": cid,
            "name": cell.name,
            "x": cell.x,
            "y": cell.y,
            "tx_power_dbm": cell.active_tx_power_dbm,
            "power_state": cell.power_state.value,
            "load_ratio": cell.current_load_ratio,
            "allocated_prbs": cell.allocated_prbs,
            "connected_ues": ues
        })
    return {
        "grid_bounds": {"min_x": -300, "max_x": 1200, "min_y": -300, "max_y": 1200},
        "cells": cells_data
    }


@app.get("/api/interview-guide")
def get_interview_guide():
    """Returns comprehensive explanations and interview-ready answers for all 6 pillars."""
    return {
        "framework": "AI/ML ➔ Traffic Prediction ➔ Resource Optimization ➔ Better Network Performance",
        "pillars": [
            {
                "id": "spectrum",
                "title": "Spectrum Optimization 📡",
                "core_concept": "Spectrum refers to the radio-frequency bands used to transmit signals (e.g., 3.5 GHz n78). Because spectrum is scarce and user demand fluctuates, static allocation causes severe starvation in busy cells and wasted capacity in idle cells.",
                "how_ml_helps": "ML models forecast PRB demand across cells by analyzing user count, traffic demand, CQI, and historical utilization. It dynamically pools and redistributes PRB allocations (Dynamic Spectrum Sharing) to cells needing them most.",
                "example": "Cell A (Downtown) at 90% load vs Cell B at 30% load. Instead of static 273 PRBs each, ML dynamically reallocates +120 PRBs from the shared pool to Cell A, boosting throughput by over 30% without dropping calls in Cell B.",
                "interview_answer": "ML learns traffic demand and radio conditions to predict future spectrum requirements. The network dynamically allocates spectrum and PRB resources from an elastic pool to cells with the highest demand, maximizing spectral efficiency and preventing congestion."
            },
            {
                "id": "power",
                "title": "Power & Energy Optimization ⚡",
                "core_concept": "Base station power amplifiers (PAs) and transceivers consume up to 80% of total cellular network electricity, operating continuously at full power even during low-traffic night hours.",
                "how_ml_helps": "ML predicts diurnal and temporal traffic drops. During low demand, the base station engages multi-level energy savings: symbol-level Micro-Sleep (muting empty slots), dynamic PA scaling, and full carrier Deep Sleep.",
                "example": "At 03:00 AM, traffic drops by 80%. ML detects the lull, verifies that no mission-critical URLLC sessions are active, and places secondary carriers into Deep Sleep while neighbor cells provide umbrella coverage, saving over 30% of base station kWh.",
                "interview_answer": "ML predicts traffic demand and network load, allowing the RAN to dynamically adjust transmission power or place underutilized resources into micro-sleep or deep-sleep states while strictly guaranteeing quality of service."
            },
            {
                "id": "scheduling",
                "title": "Scheduling Optimization 📅",
                "core_concept": "The MAC scheduler decides which user gets radio resources (PRBs) in each subframe. Traditional rules (Round Robin or Proportional Fair) suffer harsh trade-offs between throughput, fairness, and latency deadlines.",
                "how_ml_helps": "AI-native schedulers evaluate instantaneous CQI, buffer backlogs, delay deadlines, and QoS weights simultaneously. It dynamically prioritizes URLLC packets before latency expires while opportunistically scheduling eMBB during high CQI moments.",
                "example": "When a connected autonomous vehicle requires a low-latency packet (URLLC target <5ms), the AI scheduler detects the queue delay exponent and allocates dedicated PRBs instantly, avoiding packet drop spikes common in Round Robin.",
                "interview_answer": "ML enhances scheduling by jointly evaluating channel quality, traffic demand, delay deadlines, and QoS requirements, making optimal sub-millisecond resource assignments that slash latency and eliminate SLA violations."
            },
            {
                "id": "capacity",
                "title": "Capacity Optimization 📊",
                "core_concept": "Capacity is the maximum traffic load a cell can support before performance degrades. When approaching 90-100% capacity, latency explodes and packet drop rates surge.",
                "how_ml_helps": "ML monitors user influx rates and predicts impending cell saturation 15-30 minutes before it happens, triggering preventive traffic steering, handover offset adjustments, and slice re-dimensioning.",
                "example": "Cell A reaches 85 users (limit 100). ML predicts demand will exceed 110 within 20 minutes. It proactively steers 12 boundary users to neighboring Cell B (load 40%) by adjusting the 3GPP A3 Handover Margin, preventing an outage.",
                "interview_answer": "ML predicts future network load and capacity exhaustion, allowing operators to proactively allocate resources or redistribute traffic to adjacent cells before congestion and dropped calls occur."
            },
            {
                "id": "interference",
                "title": "Interference Optimization 📶",
                "core_concept": "Inter-cell interference occurs when unwanted radio signals from neighbor cells degrade the desired signal at cell boundaries, severely degrading cell-edge SINR.",
                "how_ml_helps": "ML analyzes UE RSRP/SINR reports and antenna beam patterns. It applies coordinated multi-point (CoMP), spatial nulling, and inter-cell interference coordination (eICIC) to eliminate cross-talk.",
                "example": "A cell-edge user between Cell A and Cell B experiences severe SINR degradation (2 dB). ML coordinates with Cell B to down-tilt its beam and reduce power on overlapping PRBs, boosting the user's SINR to 7.5 dB and doubling throughput.",
                "interview_answer": "ML learns interference patterns from radio measurements and optimizes transmission power, beam configurations, and resource coordination to suppress inter-cell interference and elevate cell-edge throughput."
            },
            {
                "id": "traffic",
                "title": "Traffic Optimization & Steering 🚦",
                "core_concept": "Cellular traffic experiences dramatic swings (rush hours, lunch peaks, sporting events, night lulls). Static network configurations cannot cope with these dynamic shifts.",
                "how_ml_helps": "ML algorithms train on historical time-series data to predict traffic surges and anomalies (e.g. stadium concerts). The network steers traffic via mobility load balancing (MLB) to distribute the load across the entire cluster.",
                "example": "Rush hour downtown: Downtown Cell A spikes to 95% load while Suburban Cell B is at 35%. ML steers overlapping commuter UEs to Cell B, balancing cluster load to 65% each.",
                "interview_answer": "ML forecasts multi-cell traffic dynamics from historical patterns and real-time trends, enabling proactive traffic steering and dynamic load balancing across carrier frequencies and neighboring cells."
            }
        ]
    }


from fastapi.responses import FileResponse

# Static Web Routes
web_dir = os.path.join(os.path.dirname(__file__), "web")

@app.get("/")
def serve_index():
    return FileResponse(os.path.join(web_dir, "index.html"))

@app.get("/app.css")
def serve_css():
    return FileResponse(os.path.join(web_dir, "app.css"), media_type="text/css")

@app.get("/app.js")
def serve_js():
    return FileResponse(os.path.join(web_dir, "app.js"), media_type="application/javascript")


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
