"""
Unit and Integration Tests for Nokia AI-RAN Optimization Platform
Tests the 5G NR Simulator, all 6 ML Optimization Pillars, and Closed-Loop Orchestrator.
"""

import unittest
import numpy as np
from core.simulator.network_sim import NetworkSimulator, PowerState, TrafficType
from core.models.traffic_predictor import TrafficPredictor
from core.models.spectrum_optimizer import SpectrumOptimizer
from core.models.energy_saver import EnergySaver
from core.models.scheduler import IntelligentScheduler
from core.models.capacity_guard import CapacityGuard
from core.models.interference_mitigator import InterferenceMitigator
from core.orchestrator import AIRANOrchestrator


class TestAIRANSystem(unittest.TestCase):

    def setUp(self):
        self.sim = NetworkSimulator(seed=123)

    def test_simulator_initialization(self):
        """Verify cell topology, coordinates, and initial UEs."""
        self.assertEqual(len(self.sim.cells), 3)
        self.assertIn("Cell_A", self.sim.cells)
        self.assertIn("Cell_B", self.sim.cells)
        self.assertIn("Cell_C", self.sim.cells)

        total_ues = sum(len(c.connected_ues) for c in self.sim.cells.values())
        self.assertGreater(total_ues, 30)

    def test_traffic_predictor(self):
        """Verify supervised traffic prediction returns valid forecasts."""
        predictor = TrafficPredictor()
        telemetry = self.sim.get_cell_telemetry()
        predictions = predictor.predict_demand(14.0, telemetry)

        self.assertEqual(len(predictions), 3)
        for cid, pred in predictions.items():
            self.assertIn("predicted_ues_15m", pred)
            self.assertIn("predicted_prbs_15m", pred)
            self.assertGreater(pred["predicted_prbs_15m"], 0)
            self.assertIn(pred["demand_trend"], ["increasing", "decreasing", "stable"])

    def test_spectrum_optimizer(self):
        """Verify dynamic PRB allocation satisfies sum constraint."""
        predictor = TrafficPredictor()
        telemetry = self.sim.get_cell_telemetry()
        predictions = predictor.predict_demand(14.0, telemetry)

        optimizer = SpectrumOptimizer(total_shared_prbs=819, min_prb_guarantee=50)
        allocations = optimizer.optimize_spectrum_allocation(predictions, telemetry)

        total_allocated = sum(v["allocated_prbs"] for v in allocations.values())
        self.assertEqual(total_allocated, 819)
        for cid, v in allocations.items():
            self.assertGreaterEqual(v["allocated_prbs"], 50)
            self.assertIn("satisfaction_rate_ai", v)

    def test_energy_saver(self):
        """Verify green RAN power policy transitions and energy savings."""
        saver = EnergySaver()
        pred_low = {"predicted_ues_15m": 3.0}
        telemetry_low = {"load_ratio": 0.05, "active_ues": 2}
        
        eval_low = saver.evaluate_energy_policy("Cell_B", pred_low, telemetry_low, has_urllc_active=False)
        self.assertEqual(eval_low["recommended_state"], PowerState.DEEP_SLEEP.value)
        self.assertGreater(eval_low["energy_savings_pct"], 50.0)

        # High load test
        pred_high = {"predicted_ues_15m": 70.0}
        telemetry_high = {"load_ratio": 0.88, "active_ues": 65}
        eval_high = saver.evaluate_energy_policy("Cell_A", pred_high, telemetry_high, has_urllc_active=True)
        self.assertEqual(eval_high["recommended_state"], PowerState.ACTIVE_MAX.value)

    def test_intelligent_scheduler(self):
        """Verify AI-Native scheduler outperforms Round Robin on latency."""
        scheduler = IntelligentScheduler()
        ues = list(self.sim.cells["Cell_A"].connected_ues.values())[:10]
        results = scheduler.benchmark_schedulers(ues, total_prbs=273)

        self.assertIn("AI_Native", results)
        self.assertIn("Round_Robin", results)
        self.assertIn("Proportional_Fair", results)
        
        ai_res = results["AI_Native"]
        self.assertGreater(ai_res["total_throughput_mbps"], 0.0)
        self.assertGreaterEqual(ai_res["jains_fairness_index"], 0.0)

    def test_capacity_guard_steering(self):
        """Verify proactive steering migrates boundary UEs."""
        guard = CapacityGuard(capacity_limit_ues=80, congestion_threshold=0.8)
        initial_ues_a = len(self.sim.cells["Cell_A"].connected_ues)
        initial_ues_b = len(self.sim.cells["Cell_B"].connected_ues)

        res = guard.execute_proactive_traffic_steering(self.sim, "Cell_A", "Cell_B", max_ues_to_steer=5)
        
        if res["steered_count"] > 0:
            self.assertEqual(len(self.sim.cells["Cell_A"].connected_ues), initial_ues_a - res["steered_count"])
            self.assertEqual(len(self.sim.cells["Cell_B"].connected_ues), initial_ues_b + res["steered_count"])

    def test_interference_mitigator(self):
        """Verify interference analysis and coordination."""
        mitigator = InterferenceMitigator()
        analysis = mitigator.analyze_interference_hotspots(self.sim)
        self.assertEqual(len(analysis), 3)

        coord_res = mitigator.optimize_interference_coordination(self.sim)
        self.assertIn("overall_edge_sinr_gain_db", coord_res)

    def test_orchestrator_closed_loop(self):
        """Verify orchestrator runs both AI and baseline steps without exceptions."""
        orch_ai = AIRANOrchestrator(mode="AI_ENABLED")
        res_ai = orch_ai.run_step()
        self.assertIsNotNone(res_ai["ai_decisions"])
        self.assertEqual(len(res_ai["telemetry"]), 3)

        orch_leg = AIRANOrchestrator(mode="LEGACY_BASELINE")
        res_leg = orch_leg.run_step()
        self.assertIsNone(res_leg["ai_decisions"])


if __name__ == "__main__":
    unittest.main()
