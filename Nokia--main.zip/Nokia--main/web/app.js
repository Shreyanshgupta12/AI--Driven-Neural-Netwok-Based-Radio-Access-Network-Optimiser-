/**
 * Nokia AI-RAN Web Application Controller
 * Handles real-time telemetry streaming, Canvas 2D topology rendering,
 * Chart.js metrics visualization, and scenario simulation.
 */

// Application State
const state = {
  mode: "AI_ENABLED",
  scenario: "normal",
  hour: 8.0,
  step: 0,
  isAutoPlaying: false,
  autoPlayInterval: null,
  telemetry: {},
  aiDecisions: {},
  topology: null,
  benchmarkData: null,
  events: []
};

// Chart References
const charts = {
  spectrum: null,
  power: null,
  scheduler: null,
  sinr: null,
  traffic: null,
  benchTp: null,
  benchPw: null
};

// Canvas references
let canvas, ctx;
let hoveredUE = null;

// Initialize on DOM Ready
document.addEventListener("DOMContentLoaded", () => {
  canvas = document.getElementById("topologyCanvas");
  ctx = canvas.getContext("2d");

  initEventListeners();
  initCanvasListeners();
  initCharts();
  fetchStatus();
  fetchTopology();
  fetchInterviewGuide();
  fetchBenchmark();

  // Run first simulation step to seed dashboard
  stepSimulation();
});

// Event Listeners
function initEventListeners() {
  // Step Button
  document.getElementById("btnStep").addEventListener("click", () => {
    stepSimulation();
  });

  // Auto-Play Toggle
  document.getElementById("btnAutoPlay").addEventListener("click", () => {
    toggleAutoPlay();
  });

  // Reset Button
  document.getElementById("btnReset").addEventListener("click", () => {
    resetSimulation();
  });

  // Scenario Selector
  document.getElementById("scenarioSelect").addEventListener("change", (e) => {
    setScenario(e.target.value);
  });

  // Mode Switch
  document.getElementById("modeSwitch").addEventListener("change", (e) => {
    setMode(e.target.checked ? "AI_ENABLED" : "LEGACY_BASELINE");
  });

  // Benchmark Re-run
  document.getElementById("btnRunBenchmark").addEventListener("click", () => {
    fetchBenchmark();
  });

  // Navigation Tabs
  const tabBtns = document.querySelectorAll(".tab-btn");
  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      tabBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      const targetTab = btn.getAttribute("data-tab");
      document.querySelectorAll(".tab-pane").forEach(pane => {
        pane.classList.remove("active");
      });
      const activePane = document.getElementById(`pane-${targetTab}`);
      if (activePane) activePane.classList.add("active");

      // Trigger resize for chart responsiveness
      setTimeout(() => {
        Object.values(charts).forEach(c => {
          if (c) c.resize();
        });
      }, 50);
    });
  });
}

// API Calls
async function fetchStatus() {
  try {
    const res = await fetch("/api/status");
    const data = await res.json();
    state.mode = data.mode;
    state.scenario = data.current_scenario;
    state.hour = data.simulation_hour;
    state.step = data.total_steps;
    updateStatusUI();
  } catch (err) {
    console.error("Error fetching status:", err);
  }
}

async function stepSimulation() {
  try {
    const res = await fetch("/api/step", { method: "POST" });
    const data = await res.json();
    state.hour = data.hour;
    state.step = data.step;
    state.telemetry = data.telemetry;
    state.aiDecisions = data.ai_decisions || {};
    
    // Update live clock
    updateClockUI();
    renderCellCards();
    updateFlowRibbon();

    // Fetch refreshed topology
    await fetchTopology();

    // Refresh active tab views
    updateSpectrumView();
    updatePowerView();
    updateSchedulingView();
    updateCapacityView();
    updateInterferenceView();
    updateTrafficView();

    // Log events if any
    if (state.aiDecisions && state.aiDecisions.steering_actions) {
      state.aiDecisions.steering_actions.forEach(action => {
        if (action.steered_count > 0) {
          addEventLog("steering", `Steered ${action.steered_count} UEs from ${action.source_cell} to ${action.target_cell} (Proactive MLB)`);
        }
      });
    }
  } catch (err) {
    console.error("Error running simulation step:", err);
  }
}

async function setScenario(scenarioName) {
  try {
    await fetch("/api/scenario", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scenario: scenarioName })
    });
    state.scenario = scenarioName;
    addEventLog("system", `Scenario changed to '${scenarioName}'.`);
    stepSimulation();
  } catch (err) {
    console.error("Error setting scenario:", err);
  }
}

async function setMode(modeName) {
  try {
    await fetch("/api/mode", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: modeName })
    });
    state.mode = modeName;
    updateStatusUI();
    addEventLog("system", `Orchestrator mode toggled to '${modeName}'.`);
    stepSimulation();
  } catch (err) {
    console.error("Error setting mode:", err);
  }
}

async function resetSimulation() {
  try {
    await fetch("/api/reset", { method: "POST" });
    addEventLog("system", "Network simulation reset to 08:00 AM.");
    stepSimulation();
  } catch (err) {
    console.error("Error resetting simulation:", err);
  }
}

async function fetchTopology() {
  try {
    const res = await fetch("/api/topology");
    state.topology = await res.json();
    renderTopologyCanvas();
  } catch (err) {
    console.error("Error fetching topology:", err);
  }
}

async function fetchBenchmark() {
  try {
    const res = await fetch("/api/benchmark");
    state.benchmarkData = await res.json();
    renderBenchmarkView();
  } catch (err) {
    console.error("Error fetching benchmark:", err);
  }
}

async function fetchInterviewGuide() {
  try {
    const res = await fetch("/api/interview-guide");
    const data = await res.json();
    renderInterviewGuide(data.pillars);
  } catch (err) {
    console.error("Error fetching interview guide:", err);
  }
}

function toggleAutoPlay() {
  state.isAutoPlaying = !state.isAutoPlaying;
  const btn = document.getElementById("btnAutoPlay");
  const text = document.getElementById("autoPlayText");
  const icon = document.getElementById("playIcon");

  if (state.isAutoPlaying) {
    btn.classList.add("btn-primary-active");
    text.textContent = "Pause Auto-Play";
    icon.innerHTML = '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>';
    state.autoPlayInterval = setInterval(() => {
      stepSimulation();
    }, 1400);
  } else {
    btn.classList.remove("btn-primary-active");
    text.textContent = "Live Auto-Play";
    icon.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"></polygon>';
    clearInterval(state.autoPlayInterval);
  }
}

// UI Updaters
function updateStatusUI() {
  const badge = document.getElementById("liveStatusBadge");
  const text = document.getElementById("statusText");
  const modeSwitch = document.getElementById("modeSwitch");

  if (state.mode === "AI_ENABLED") {
    badge.style.background = "rgba(0, 255, 157, 0.1)";
    badge.style.borderColor = "rgba(0, 255, 157, 0.3)";
    badge.style.color = "var(--cyber-emerald)";
    text.textContent = "AI-NATIVE ACTIVE";
    modeSwitch.checked = true;
  } else {
    badge.style.background = "rgba(255, 183, 0, 0.1)";
    badge.style.borderColor = "rgba(255, 183, 0, 0.3)";
    badge.style.color = "var(--cyber-amber)";
    text.textContent = "LEGACY STATIC RAN";
    modeSwitch.checked = false;
  }
}

function updateClockUI() {
  const h = Math.floor(state.hour);
  const m = Math.round((state.hour - h) * 60);
  const ampm = h >= 12 ? "PM" : "AM";
  const displayH = h % 12 === 0 ? 12 : h % 12;
  const timeStr = `${String(displayH).padStart(2, "0")}:${String(m).padStart(2, "0")} ${ampm}`;

  document.getElementById("simClock").textContent = timeStr;
  document.getElementById("simStep").textContent = `#${state.step}`;
}

function updateFlowRibbon() {
  const totalTp = Object.values(state.telemetry).reduce((acc, c) => acc + c.throughput_mbps, 0);
  const totalPower = Object.values(state.telemetry).reduce((acc, c) => acc + c.power_watts, 0);

  const siliconSub = document.getElementById("flowSilicon");
  const demandSub = document.getElementById("flowDemand");
  const actionSub = document.getElementById("flowAction");
  const perfSub = document.getElementById("flowPerf");

  if (state.mode === "AI_ENABLED") {
    siliconSub.textContent = "Real-time AI at Silicon (64T64R)";
    demandSub.textContent = `Forecast: Peak Cluster PRB Load`;
    actionSub.textContent = `Dynamic Spectrum & Micro-Sleep`;
    perfSub.textContent = `${totalTp.toFixed(0)} Mbps | ${(totalPower / 1000).toFixed(1)} kW Cluster`;
  } else {
    siliconSub.textContent = "Static Firmware (Fixed 46 dBm)";
    demandSub.textContent = "No Demand Prediction Active";
    actionSub.textContent = "Fixed 273 PRBs / Static Partitions";
    perfSub.textContent = `${totalTp.toFixed(0)} Mbps (Legacy Baseline)`;
  }
}

function renderCellCards() {
  const container = document.getElementById("cellCardsContainer");
  if (!container || !state.telemetry) return;

  container.innerHTML = "";

  Object.entries(state.telemetry).forEach(([cid, data]) => {
    const card = document.createElement("div");
    card.className = "cell-card";

    let stateClass = "state-active";
    if (data.power_state.includes("micro")) stateClass = "state-micro";
    else if (data.power_state.includes("deep")) stateClass = "state-deep";

    const loadPct = (data.load_ratio * 100).toFixed(1);
    let loadFillClass = "load-normal";
    if (data.load_ratio > 0.8) loadFillClass = "load-critical";
    else if (data.load_ratio > 0.6) loadFillClass = "load-warn";

    card.innerHTML = `
      <div class="cell-card-top">
        <span class="cell-name">${data.name.split(" ")[0]} (${cid})</span>
        <span class="cell-state-badge ${stateClass}">${data.power_state}</span>
      </div>
      <div class="cell-metric-row">
        <span class="m-label">Connected UEs</span>
        <span class="m-val">${data.active_ues}</span>
      </div>
      <div class="cell-metric-row">
        <span class="m-label">Throughput</span>
        <span class="m-val">${data.throughput_mbps} Mbps</span>
      </div>
      <div class="cell-metric-row">
        <span class="m-label">PRBs / Power</span>
        <span class="m-val">${data.prb_quota} PRBs &bull; ${(data.power_watts/1000).toFixed(1)} kW</span>
      </div>
      <div class="cell-load-bar-wrap" title="Load: ${loadPct}%">
        <div class="cell-load-bar-fill ${loadFillClass}" style="width: ${Math.min(100, loadPct)}%;"></div>
      </div>
    `;
    container.appendChild(card);
  });
}

function addEventLog(type, message) {
  const feed = document.getElementById("eventFeed");
  if (!feed) return;

  const item = document.createElement("div");
  item.className = `event-item ${type}`;

  const h = Math.floor(state.hour);
  const m = Math.round((state.hour - h) * 60);
  const timeStr = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;

  item.innerHTML = `
    <span class="event-time">${timeStr}</span>
    <span class="event-text">${message}</span>
  `;
  feed.insertBefore(item, feed.firstChild);

  // Keep max 25 items
  while (feed.children.length > 25) {
    feed.removeChild(feed.lastChild);
  }

  const countBadge = document.getElementById("eventCount");
  if (countBadge) countBadge.textContent = `${feed.children.length} Events`;
}

// 2D Canvas Topology Map Renderer
function renderTopologyCanvas() {
  if (!canvas || !ctx || !state.topology) return;

  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  // Grid background lines
  ctx.strokeStyle = "rgba(0, 210, 255, 0.05)";
  ctx.lineWidth = 1;
  for (let x = 0; x < w; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  // Coordinate mapping function
  const bounds = state.topology.grid_bounds;
  const mapX = (x) => ((x - bounds.min_x) / (bounds.max_x - bounds.min_x)) * (w - 100) + 50;
  const mapY = (y) => ((y - bounds.min_y) / (bounds.max_y - bounds.min_y)) * (h - 100) + 50;

  // Draw Inter-cell handover lines if any
  state.topology.cells.forEach(cell => {
    cell.connected_ues.forEach(ue => {
      if (ue.handover_cand) {
        const targetCell = state.topology.cells.find(c => c.id === ue.handover_cand);
        if (targetCell) {
          ctx.strokeStyle = "rgba(0, 255, 157, 0.4)";
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(mapX(ue.x), mapY(ue.y));
          ctx.lineTo(mapX(targetCell.x), mapY(targetCell.y));
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }
    });
  });

  // Draw Cell Base Stations & Coverage Radii
  state.topology.cells.forEach(cell => {
    const cx = mapX(cell.x);
    const cy = mapY(cell.y);

    // Coverage Radius Circle
    const radius = 130;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
    
    if (cell.power_state === "deep_sleep") {
      ctx.fillStyle = "rgba(255, 183, 0, 0.03)";
      ctx.strokeStyle = "rgba(255, 183, 0, 0.2)";
    } else if (cell.power_state === "micro_sleep") {
      ctx.fillStyle = "rgba(0, 210, 255, 0.04)";
      ctx.strokeStyle = "rgba(0, 210, 255, 0.25)";
    } else {
      ctx.fillStyle = "rgba(0, 90, 255, 0.06)";
      ctx.strokeStyle = "rgba(0, 210, 255, 0.4)";
    }
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Active Massive MIMO Beams towards UEs
    if (cell.power_state !== "deep_sleep") {
      cell.connected_ues.slice(0, 8).forEach(ue => {
        const ux = mapX(ue.x);
        const uy = mapY(ue.y);
        ctx.strokeStyle = ue.type === "URLLC" ? "rgba(255, 51, 102, 0.35)" : "rgba(0, 210, 255, 0.2)";
        ctx.lineWidth = ue.type === "URLLC" ? 2 : 1;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(ux, uy);
        ctx.stroke();
      });
    }

    // Base Station Icon (Hexagon)
    drawHexagon(ctx, cx, cy, 18, cell.power_state === "deep_sleep" ? "#ffb700" : "#00d2ff");

    // Cell Label
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 11px Outfit";
    ctx.textAlign = "center";
    ctx.fillText(`${cell.name.split(" ")[0]} (${cell.allocated_prbs} PRBs)`, cx, cy - 26);
  });

  // Draw Connected UEs
  state.topology.cells.forEach(cell => {
    cell.connected_ues.forEach(ue => {
      const ux = mapX(ue.x);
      const uy = mapY(ue.y);

      ctx.beginPath();
      ctx.arc(ux, uy, ue.type === "URLLC" ? 5 : 4, 0, 2 * Math.PI);

      if (ue.type === "URLLC") {
        ctx.fillStyle = "#ff3366";
        ctx.shadowColor = "#ff3366";
        ctx.shadowBlur = 8;
      } else if (ue.type === "eMBB") {
        ctx.fillStyle = "#00d2ff";
        ctx.shadowColor = "#00d2ff";
        ctx.shadowBlur = 6;
      } else {
        ctx.fillStyle = "#ffb700";
        ctx.shadowColor = "#ffb700";
        ctx.shadowBlur = 4;
      }
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  });

  // Render Hover Tooltip
  if (hoveredUE) {
    renderTooltip(mapX(hoveredUE.x), mapY(hoveredUE.y), hoveredUE);
  }
}

function drawHexagon(ctx, x, y, radius, strokeColor) {
  ctx.save();
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 3) * i;
    const hx = x + radius * Math.cos(angle);
    const hy = y + radius * Math.sin(angle);
    if (i === 0) ctx.moveTo(hx, hy);
    else ctx.lineTo(hx, hy);
  }
  ctx.closePath();
  ctx.fillStyle = "rgba(4, 10, 23, 0.9)";
  ctx.fill();
  ctx.strokeStyle = strokeColor;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Core dot
  ctx.beginPath();
  ctx.arc(x, y, 4, 0, 2 * Math.PI);
  ctx.fillStyle = strokeColor;
  ctx.fill();
  ctx.restore();
}

function renderTooltip(x, y, ue) {
  ctx.save();
  const pad = 8;
  const boxW = 160;
  const boxH = 75;
  const tx = Math.min(canvas.width - boxW - 10, Math.max(10, x + 10));
  const ty = Math.min(canvas.height - boxH - 10, Math.max(10, y - 60));

  ctx.fillStyle = "rgba(8, 19, 38, 0.95)";
  ctx.strokeStyle = "rgba(0, 210, 255, 0.5)";
  ctx.lineWidth = 1;
  ctx.fillRect(tx, ty, boxW, boxH);
  ctx.strokeRect(tx, ty, boxW, boxH);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 11px Outfit";
  ctx.textAlign = "left";
  ctx.fillText(`UE #${ue.id} [${ue.type}]`, tx + pad, ty + 18);

  ctx.fillStyle = "#8b9bb4";
  ctx.font = "10px JetBrains Mono";
  ctx.fillText(`CQI: ${ue.cqi} | SINR: ${ue.sinr_db} dB`, tx + pad, ty + 34);
  ctx.fillText(`Rate: ${ue.rate_mbps} Mbps | Delay: ${ue.delay_ms}ms`, tx + pad, ty + 48);
  ctx.fillText(`Assigned: ${ue.prbs} PRBs`, tx + pad, ty + 62);
  ctx.restore();
}

function initCanvasListeners() {
  canvas.addEventListener("mousemove", (e) => {
    if (!state.topology) return;
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
    const my = (e.clientY - rect.top) * (canvas.height / rect.height);

    const bounds = state.topology.grid_bounds;
    const mapX = (x) => ((x - bounds.min_x) / (bounds.max_x - bounds.min_x)) * (canvas.width - 100) + 50;
    const mapY = (y) => ((y - bounds.min_y) / (bounds.max_y - bounds.min_y)) * (canvas.height - 100) + 50;

    let found = null;
    state.topology.cells.forEach(c => {
      c.connected_ues.forEach(u => {
        const dist = Math.hypot(mapX(u.x) - mx, mapY(u.y) - my);
        if (dist < 8) found = u;
      });
    });

    hoveredUE = found;
    renderTopologyCanvas();
  });

  canvas.addEventListener("mouseleave", () => {
    hoveredUE = null;
    renderTopologyCanvas();
  });
}

// Charts Initialization
function initCharts() {
  const chartDefaults = {
    responsive: true,
    maintainAspectRatio: false,
    color: "#8b9bb4",
    font: { family: "Outfit" }
  };

  // 1. Spectrum Chart
  const ctxSpec = document.getElementById("spectrumChart");
  if (ctxSpec) {
    charts.spectrum = new Chart(ctxSpec, {
      type: "bar",
      data: {
        labels: ["Cell A (Urban)", "Cell B (Suburban)", "Cell C (Industrial)"],
        datasets: [
          {
            label: "Allocated PRBs (AI)",
            data: [273, 273, 273],
            backgroundColor: "rgba(0, 210, 255, 0.7)",
            borderColor: "rgba(0, 210, 255, 1)",
            borderWidth: 1
          },
          {
            label: "Predicted Demand (PRBs)",
            data: [250, 180, 140],
            backgroundColor: "rgba(0, 255, 157, 0.4)",
            borderColor: "rgba(0, 255, 157, 1)",
            borderWidth: 1
          },
          {
            label: "Legacy Static Baseline (273)",
            data: [273, 273, 273],
            type: "line",
            borderColor: "rgba(255, 51, 102, 0.8)",
            borderDash: [5, 5],
            fill: false
          }
        ]
      },
      options: {
        ...chartDefaults,
        scales: {
          y: { beginAtZero: true, max: 500, grid: { color: "rgba(255,255,255,0.05)" } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  // 2. Power Chart
  const ctxPower = document.getElementById("powerChart");
  if (ctxPower) {
    charts.power = new Chart(ctxPower, {
      type: "bar",
      data: {
        labels: ["Cell A", "Cell B", "Cell C"],
        datasets: [
          {
            label: "Current AI Power (Watts)",
            data: [18000, 14000, 12000],
            backgroundColor: "rgba(0, 255, 157, 0.65)"
          },
          {
            label: "Legacy Full Power (Watts)",
            data: [18381, 18381, 18381],
            backgroundColor: "rgba(255, 51, 102, 0.35)"
          }
        ]
      },
      options: {
        ...chartDefaults,
        scales: {
          y: { beginAtZero: true, max: 22000, grid: { color: "rgba(255,255,255,0.05)" } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  // 3. Scheduler Comparison Chart
  const ctxSched = document.getElementById("schedulerCompareChart");
  if (ctxSched) {
    charts.scheduler = new Chart(ctxSched, {
      type: "bar",
      data: {
        labels: ["Round Robin (RR)", "Proportional Fair (PF)", "Nokia AI-Native"],
        datasets: [
          {
            label: "Throughput (Mbps)",
            data: [65, 92, 128],
            backgroundColor: "rgba(0, 210, 255, 0.7)",
            yAxisID: "y"
          },
          {
            label: "URLLC Avg Delay (ms)",
            data: [14.2, 8.5, 3.2],
            backgroundColor: "rgba(255, 51, 102, 0.7)",
            yAxisID: "y1"
          }
        ]
      },
      options: {
        ...chartDefaults,
        scales: {
          y: { type: "linear", position: "left", beginAtZero: true, title: { display: true, text: "Mbps" } },
          y1: { type: "linear", position: "right", beginAtZero: true, title: { display: true, text: "Delay ms" }, grid: { display: false } }
        }
      }
    });
  }

  // 4. SINR Chart
  const ctxSinr = document.getElementById("sinrChart");
  if (ctxSinr) {
    charts.sinr = new Chart(ctxSinr, {
      type: "bar",
      data: {
        labels: ["Cell A (Edge)", "Cell A (Avg)", "Cell B (Edge)", "Cell B (Avg)", "Cell C (Edge)", "Cell C (Avg)"],
        datasets: [
          {
            label: "AI-Coordinated SINR (dB)",
            data: [6.5, 16.2, 7.8, 17.5, 8.2, 18.0],
            backgroundColor: "rgba(0, 255, 157, 0.7)"
          }
        ]
      },
      options: {
        ...chartDefaults,
        scales: {
          y: { beginAtZero: true, max: 25, title: { display: true, text: "SINR (dB)" }, grid: { color: "rgba(255,255,255,0.05)" } }
        }
      }
    });
  }

  // 5. Traffic Forecast Chart
  const ctxTraffic = document.getElementById("trafficForecastChart");
  if (ctxTraffic) {
    const hours = Array.from({ length: 24 }, (_, i) => `${i}:00`);
    charts.traffic = new Chart(ctxTraffic, {
      type: "line",
      data: {
        labels: hours,
        datasets: [
          {
            label: "Cell A Demand (Downtown Hotspot)",
            data: [15, 12, 10, 8, 12, 35, 75, 95, 85, 90, 80, 75, 85, 92, 88, 95, 110, 105, 80, 65, 50, 35, 25, 18],
            borderColor: "#00d2ff",
            backgroundColor: "rgba(0, 210, 255, 0.1)",
            fill: true,
            tension: 0.35
          },
          {
            label: "Cell B Demand (Suburban Residential)",
            data: [12, 10, 8, 6, 8, 15, 30, 45, 40, 35, 32, 35, 42, 45, 50, 65, 80, 92, 95, 85, 60, 45, 30, 18],
            borderColor: "#00ff9d",
            backgroundColor: "rgba(0, 255, 157, 0.08)",
            fill: true,
            tension: 0.35
          },
          {
            label: "Cell C Demand (Tech/Industrial Park)",
            data: [8, 6, 5, 4, 6, 12, 40, 70, 85, 90, 88, 85, 82, 80, 78, 75, 60, 45, 25, 18, 14, 12, 10, 8],
            borderColor: "#ffb700",
            backgroundColor: "rgba(255, 183, 0, 0.08)",
            fill: true,
            tension: 0.35
          }
        ]
      },
      options: {
        ...chartDefaults,
        scales: {
          y: { beginAtZero: true, max: 130, title: { display: true, text: "Active UEs / PRB Demand" }, grid: { color: "rgba(255,255,255,0.05)" } }
        }
      }
    });
  }

  // 6 & 7. Benchmark Charts
  const ctxBTp = document.getElementById("benchThroughputChart");
  const ctxBPw = document.getElementById("benchPowerChart");
  if (ctxBTp && ctxBPw) {
    charts.benchTp = new Chart(ctxBTp, {
      type: "line",
      data: { labels: [], datasets: [] },
      options: { ...chartDefaults, scales: { y: { beginAtZero: true, title: { display: true, text: "Mbps" } } } }
    });
    charts.benchPw = new Chart(ctxBPw, {
      type: "line",
      data: { labels: [], datasets: [] },
      options: { ...chartDefaults, scales: { y: { beginAtZero: true, title: { display: true, text: "Watts" } } } }
    });
  }
}

// Pillar View Updates
function updateSpectrumView() {
  if (!state.aiDecisions.spectrum_optimization || !charts.spectrum) return;
  const spec = state.aiDecisions.spectrum_optimization;

  const allocated = [spec.Cell_A.allocated_prbs, spec.Cell_B.allocated_prbs, spec.Cell_C.allocated_prbs];
  const demand = [spec.Cell_A.demand_prbs_predicted, spec.Cell_B.demand_prbs_predicted, spec.Cell_C.demand_prbs_predicted];

  charts.spectrum.data.datasets[0].data = allocated;
  charts.spectrum.data.datasets[1].data = demand;
  charts.spectrum.update();

  const breakdownContainer = document.getElementById("spectrumBreakdown");
  if (breakdownContainer) {
    breakdownContainer.innerHTML = `
      <div class="panel" style="background: rgba(255,255,255,0.02); margin-bottom: 0.75rem;">
        <strong>Cell A: ${spec.Cell_A.allocated_prbs} PRBs</strong> (${spec.Cell_A.action_summary})
        <div style="font-size:0.75rem; color:#8b9bb4; margin-top:0.2rem;">Satisfaction: AI ${spec.Cell_A.satisfaction_rate_ai}% vs Static ${spec.Cell_A.satisfaction_rate_static}%</div>
      </div>
      <div class="panel" style="background: rgba(255,255,255,0.02); margin-bottom: 0.75rem;">
        <strong>Cell B: ${spec.Cell_B.allocated_prbs} PRBs</strong> (${spec.Cell_B.action_summary})
        <div style="font-size:0.75rem; color:#8b9bb4; margin-top:0.2rem;">Satisfaction: AI ${spec.Cell_B.satisfaction_rate_ai}% vs Static ${spec.Cell_B.satisfaction_rate_static}%</div>
      </div>
      <div class="panel" style="background: rgba(255,255,255,0.02);">
        <strong>Cell C: ${spec.Cell_C.allocated_prbs} PRBs</strong> (${spec.Cell_C.action_summary})
        <div style="font-size:0.75rem; color:#8b9bb4; margin-top:0.2rem;">Satisfaction: AI ${spec.Cell_C.satisfaction_rate_ai}% vs Static ${spec.Cell_C.satisfaction_rate_static}%</div>
      </div>
    `;
  }
}

function updatePowerView() {
  if (!state.aiDecisions.power_optimization || !charts.power) return;
  const pwr = state.aiDecisions.power_optimization;

  const currentWatts = [pwr.Cell_A.optimized_power_watts, pwr.Cell_B.optimized_power_watts, pwr.Cell_C.optimized_power_watts];
  charts.power.data.datasets[0].data = currentWatts;
  charts.power.update();

  const sleepContainer = document.getElementById("sleepStatesContainer");
  if (sleepContainer) {
    sleepContainer.innerHTML = Object.entries(pwr).map(([cid, data]) => `
      <div class="panel" style="background: rgba(255,255,255,0.02); margin-bottom: 0.75rem;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <strong>${cid} Power Directive:</strong>
          <span class="cell-state-badge state-${data.recommended_state.includes('active') ? 'active' : (data.recommended_state.includes('micro') ? 'micro' : 'deep')}">${data.recommended_state}</span>
        </div>
        <p style="font-size:0.8rem; color:#8b9bb4; margin-top:0.4rem;">${data.rationale}</p>
        <div style="font-size:0.75rem; color:var(--cyber-emerald); margin-top:0.3rem;">Saved: ${data.watts_saved.toFixed(0)} W (${data.energy_savings_pct}%) &bull; Tx: ${data.recommended_tx_dbm} dBm</div>
      </div>
    `).join("");
  }
}

function updateSchedulingView() {
  if (!state.aiDecisions.scheduling_benchmarks || !charts.scheduler) return;
  const bench = state.aiDecisions.scheduling_benchmarks.Cell_A;
  if (!bench) return;

  const tps = [bench.Round_Robin.total_throughput_mbps, bench.Proportional_Fair.total_throughput_mbps, bench.AI_Native.total_throughput_mbps];
  const delays = [bench.Round_Robin.urllc_avg_delay_ms, bench.Proportional_Fair.urllc_avg_delay_ms, bench.AI_Native.urllc_avg_delay_ms];

  charts.scheduler.data.datasets[0].data = tps;
  charts.scheduler.data.datasets[1].data = delays;
  charts.scheduler.update();

  const statsBox = document.getElementById("queueStatsBox");
  if (statsBox) {
    statsBox.innerHTML = `
      <div class="cell-metric-row"><span class="m-label">AI-Native Throughput:</span><span class="m-val" style="color:var(--nokia-cyan);">${bench.AI_Native.total_throughput_mbps} Mbps</span></div>
      <div class="cell-metric-row"><span class="m-label">Round Robin Throughput:</span><span class="m-val">${bench.Round_Robin.total_throughput_mbps} Mbps</span></div>
      <div class="cell-metric-row" style="margin-top:0.5rem;"><span class="m-label">URLLC Latency (AI-Native):</span><span class="m-val" style="color:var(--cyber-emerald);">${bench.AI_Native.urllc_avg_delay_ms} ms</span></div>
      <div class="cell-metric-row"><span class="m-label">URLLC Latency (Round Robin):</span><span class="m-val" style="color:var(--cyber-rose);">${bench.Round_Robin.urllc_avg_delay_ms} ms</span></div>
      <div class="cell-metric-row" style="margin-top:0.5rem;"><span class="m-label">SLA Violations (Round Robin):</span><span class="m-val" style="color:var(--cyber-rose);">${bench.Round_Robin.sla_violations} dropped</span></div>
      <div class="cell-metric-row"><span class="m-label">SLA Violations (AI-Native):</span><span class="m-val" style="color:var(--cyber-emerald);">${bench.AI_Native.sla_violations} dropped</span></div>
    `;
  }
}

function updateCapacityView() {
  if (!state.aiDecisions.capacity_congestion) return;
  const cong = state.aiDecisions.capacity_congestion;

  const meters = document.getElementById("capacityMeters");
  if (meters) {
    meters.innerHTML = Object.entries(cong).map(([cid, data]) => {
      const riskClass = data.risk_level === "CRITICAL" ? "load-critical" : (data.risk_level === "WARNING" ? "load-warn" : "load-normal");
      return `
        <div class="panel" style="background: rgba(255,255,255,0.02); margin-bottom: 0.75rem;">
          <div style="display:flex; justify-content:space-between;">
            <strong>${cid} Congestion Risk</strong>
            <span style="font-weight:700; color:var(--text-primary);">${data.risk_level} (${(data.congestion_risk_score*100).toFixed(0)}%)</span>
          </div>
          <div class="cell-load-bar-wrap" style="margin: 0.5rem 0;">
            <div class="cell-load-bar-fill ${riskClass}" style="width: ${data.congestion_risk_score * 100}%;"></div>
          </div>
          <div style="font-size:0.75rem; color:#8b9bb4;">Current: ${data.current_ues} UEs (${data.current_load_pct}%) &bull; Saturation in: ${data.minutes_to_congestion} min</div>
        </div>
      `;
    }).join("");
  }
}

function updateInterferenceView() {
  if (!state.aiDecisions.interference_coordination || !charts.sinr) return;
  const im = state.aiDecisions.interference_coordination;

  const data = [
    im.cell_improvements.Cell_A.post_edge_sinr_db,
    im.cell_improvements.Cell_A.post_avg_sinr_db,
    im.cell_improvements.Cell_B.post_edge_sinr_db,
    im.cell_improvements.Cell_B.post_avg_sinr_db,
    im.cell_improvements.Cell_C.post_edge_sinr_db,
    im.cell_improvements.Cell_C.post_avg_sinr_db
  ];
  charts.sinr.data.datasets[0].data = data;
  charts.sinr.update();

  const dirBox = document.getElementById("interferenceDirectives");
  if (dirBox) {
    dirBox.innerHTML = `
      <p style="font-size:0.85rem; color:var(--nokia-cyan); margin-bottom:0.6rem;">Strategy: Coordinated Multi-Point (CoMP) & Dynamic Power Nulling</p>
      ${im.actions.map(a => `<div style="font-size:0.75rem; color:#f0f6fc; margin-bottom:0.4rem;">&bull; ${a}</div>`).join("")}
      <div class="concept-callout" style="margin-top:1rem;">
        <strong>Cell-Edge Restoration:</strong>
        <p>Overall cell-edge 5th-percentile SINR gain across cluster: <strong>+${im.overall_edge_sinr_gain_db} dB</strong>. Prevents call drops on highway and boundary commuters.</p>
      </div>
    `;
  }
}

function updateTrafficView() {
  // Traffic curves are rendered by Chart.js
}

// Render Benchmark Arena View
function renderBenchmarkView() {
  if (!state.benchmarkData) return;
  const b = state.benchmarkData;
  const sc = b.summary_scorecard;
  const leg = b.legacy_kpis;
  const ai = b.ai_kpis;

  const cardsContainer = document.getElementById("benchmarkCards");
  if (cardsContainer) {
    cardsContainer.innerHTML = `
      <div class="bench-card">
        <span class="bench-title">Throughput</span>
        <span class="bench-delta">+${sc.throughput_boost_pct}%</span>
        <span class="bench-compare">Legacy: ${leg.avg_throughput_mbps} Mbps &rarr; AI: ${ai.avg_throughput_mbps} Mbps</span>
      </div>
      <div class="bench-card">
        <span class="bench-title">Energy Saved</span>
        <span class="bench-delta">${sc.energy_saved_pct}%</span>
        <span class="bench-compare">${sc.kwh_saved} kWh saved (${sc.co2_emissions_avoided_kg} kg CO₂)</span>
      </div>
      <div class="bench-card">
        <span class="bench-title">Average Latency</span>
        <span class="bench-delta">-${sc.latency_reduction_pct}%</span>
        <span class="bench-compare">Legacy: ${leg.avg_latency_ms} ms &rarr; AI: ${ai.avg_latency_ms} ms</span>
      </div>
      <div class="bench-card">
        <span class="bench-title">Packet Drop Reduction</span>
        <span class="bench-delta">-${sc.packet_drop_reduction_pct}%</span>
        <span class="bench-compare">Legacy: ${leg.packet_drop_rate_pct}% &rarr; AI: ${ai.packet_drop_rate_pct}%</span>
      </div>
      <div class="bench-card">
        <span class="bench-title">Cell-Edge SINR</span>
        <span class="bench-delta">+${sc.cell_edge_sinr_gain_db} dB</span>
        <span class="bench-compare">Legacy: ${leg.edge_5th_percentile_sinr_db} dB &rarr; AI: ${ai.edge_5th_percentile_sinr_db} dB</span>
      </div>
    `;
  }

  // Update benchmark timeline charts
  if (charts.benchTp && charts.benchPw && b.timeline_series) {
    const labels = b.timeline_series.map(item => `${item.hour.toFixed(1)}h`);
    
    charts.benchTp.data.labels = labels;
    charts.benchTp.data.datasets = [
      {
        label: "Nokia AI-RAN (Mbps)",
        data: b.timeline_series.map(i => i.ai_throughput_mbps),
        borderColor: "#00ff9d",
        tension: 0.3
      },
      {
        label: "Legacy 5G RAN (Mbps)",
        data: b.timeline_series.map(i => i.legacy_throughput_mbps),
        borderColor: "#ff3366",
        borderDash: [4, 4],
        tension: 0.3
      }
    ];
    charts.benchTp.update();

    charts.benchPw.data.labels = labels;
    charts.benchPw.data.datasets = [
      {
        label: "Nokia AI-RAN Base Station Power (W)",
        data: b.timeline_series.map(i => i.ai_power_watts),
        borderColor: "#00d2ff",
        tension: 0.3
      },
      {
        label: "Legacy 5G Base Station Power (W)",
        data: b.timeline_series.map(i => i.legacy_power_watts),
        borderColor: "#ffb700",
        borderDash: [4, 4],
        tension: 0.3
      }
    ];
    charts.benchPw.update();
  }
}

// Render Interview & Explainer Guide
function renderInterviewGuide(pillars) {
  const container = document.getElementById("interviewAccordion");
  if (!container || !pillars) return;

  container.innerHTML = pillars.map((p, idx) => `
    <div class="interview-card">
      <div class="interview-header">
        <h3>${p.title}</h3>
      </div>
      <p style="font-size:0.85rem; color:#8b9bb4; margin-bottom:0.75rem;"><strong>The Problem / Concept:</strong> ${p.core_concept}</p>
      <p style="font-size:0.85rem; color:#8b9bb4; margin-bottom:0.75rem;"><strong>How ML Solves It:</strong> ${p.how_ml_helps}</p>
      <p style="font-size:0.85rem; color:#8b9bb4; margin-bottom:0.75rem;"><strong>Realistic Multi-Cell Example:</strong> ${p.example}</p>
      
      <div class="interview-answer-box">
        <span class="badge-pill">Verbatim Interview Answer</span>
        <button class="copy-btn" onclick="copyAnswer('${p.id}')">Copy Answer</button>
        <p id="ans-${p.id}">"${p.interview_answer}"</p>
      </div>
    </div>
  `).join("");
}

// Helper to copy interview answers
window.copyAnswer = function(id) {
  const el = document.getElementById(`ans-${id}`);
  if (el) {
    navigator.clipboard.writeText(el.innerText.replace(/"/g, ''));
    const btn = event.target;
    btn.textContent = "Copied!";
    setTimeout(() => { btn.textContent = "Copy Answer"; }, 2000);
  }
};
