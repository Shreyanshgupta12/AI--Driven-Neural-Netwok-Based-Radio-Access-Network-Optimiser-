"""Nokia AI-RAN Optimization Package"""
__version__ = "1.0.0"
