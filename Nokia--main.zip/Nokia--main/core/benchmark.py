"""
Comprehensive Benchmark Engine: Legacy 5G RAN vs. Nokia AI-RAN
Evaluates the quantitative performance uplift across all 6 optimization pillars
over a full 24-hour diurnal cycle with sudden rush hour and flash crowd events.
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from typing import Dict, List
import numpy as np
from core.orchestrator import AIRANOrchestrator


class BenchmarkEngine:
    """
    Executes identical simulated 24-hour traffic workloads
    under both Legacy Rule-Based RAN and Nokia AI-RAN, generating
    scientific, production-grade comparative metrics.
    """

    def __init__(self, steps: int = 96):
        # 96 steps of 15 min = 24 hours
        self.steps = steps

    def run_benchmark(self) -> Dict:
        """
        Runs dual-track simulation across all steps and computes KPI deltas.
        """
        legacy_orch = AIRANOrchestrator(mode="LEGACY_BASELINE")
        ai_orch = AIRANOrchestrator(mode="AI_ENABLED")

        # Injects standard diurnal pattern with peak rush hour at step 32-44 (16:00-19:00)
        legacy_history = []
        ai_history = []

        for step_idx in range(self.steps):
            # Inject realistic rush hour scenario midway
            if 32 <= step_idx <= 44:
                legacy_orch.sim.current_scenario = "rush_hour"
                ai_orch.sim.current_scenario = "rush_hour"
            elif 72 <= step_idx <= 84:
                legacy_orch.sim.current_scenario = "night_lull"
                ai_orch.sim.current_scenario = "night_lull"
            else:
                legacy_orch.sim.current_scenario = "normal"
                ai_orch.sim.current_scenario = "normal"

            rec_leg = legacy_orch.run_step()
            rec_ai = ai_orch.run_step()

            legacy_history.append(rec_leg)
            ai_history.append(rec_ai)

        # Compute Aggregated KPIs
        def aggregate_metrics(history: List[Dict]) -> Dict:
            throughputs = []
            latencies = []
            packet_drops = []
            powers = []
            sinrs = []
            edge_sinrs = []

            for h in history:
                t = h["telemetry"]
                for cid, c in t.items():
                    throughputs.append(c["throughput_mbps"])
                    latencies.append(c["avg_latency_ms"])
                    packet_drops.append(c["packet_loss_rate"])
                    powers.append(c["power_watts"])
                    sinrs.append(c["avg_sinr_db"])
                    edge_sinrs.append(c["edge_sinr_db"])

            # Total energy in kWh = sum(watts * 0.25h) / 1000 for each cell
            total_kwh = sum(powers) * 0.25 / 1000.0
            total_gigabytes = (sum(throughputs) * (15 * 60) / 8) / 1000.0  # Mbps * seconds / 8 / 1000 = GB

            # Energy efficiency = Total bits transmitted / Total Joules consumed
            # 1 kWh = 3.6e6 Joules
            total_joules = total_kwh * 3.6e6
            total_megabits = total_gigabytes * 8000.0
            energy_eff_mbits_per_joule = (total_megabits / max(1.0, total_joules))

            return {
                "avg_throughput_mbps": round(float(np.mean(throughputs)), 2),
                "total_traffic_gb": round(total_gigabytes, 1),
                "total_energy_kwh": round(total_kwh, 2),
                "energy_efficiency_mbits_joule": round(energy_eff_mbits_per_joule, 4),
                "avg_latency_ms": round(float(np.mean(latencies)), 2),
                "p99_latency_ms": round(float(np.percentile(latencies, 99)), 2),
                "packet_drop_rate_pct": round(float(np.mean(packet_drops)) * 100, 2),
                "avg_sinr_db": round(float(np.mean(sinrs)), 2),
                "edge_5th_percentile_sinr_db": round(float(np.percentile(edge_sinrs, 5)), 2),
            }

        leg_kpis = aggregate_metrics(legacy_history)
        ai_kpis = aggregate_metrics(ai_history)

        # Compute percentage improvements
        tp_gain_pct = round(((ai_kpis["avg_throughput_mbps"] - leg_kpis["avg_throughput_mbps"]) / leg_kpis["avg_throughput_mbps"]) * 100, 1)
        energy_saved_pct = round(((leg_kpis["total_energy_kwh"] - ai_kpis["total_energy_kwh"]) / leg_kpis["total_energy_kwh"]) * 100, 1)
        latency_reduction_pct = round(((leg_kpis["avg_latency_ms"] - ai_kpis["avg_latency_ms"]) / leg_kpis["avg_latency_ms"]) * 100, 1)
        p99_latency_reduction_pct = round(((leg_kpis["p99_latency_ms"] - ai_kpis["p99_latency_ms"]) / leg_kpis["p99_latency_ms"]) * 100, 1)
        drop_reduction_pct = round(((leg_kpis["packet_drop_rate_pct"] - ai_kpis["packet_drop_rate_pct"]) / max(0.01, leg_kpis["packet_drop_rate_pct"])) * 100, 1)
        edge_sinr_gain_db = round(ai_kpis["edge_5th_percentile_sinr_db"] - leg_kpis["edge_5th_percentile_sinr_db"], 2)
        co2_saved_kg = round((leg_kpis["total_energy_kwh"] - ai_kpis["total_energy_kwh"]) * 0.45, 1)

        summary_scorecard = {
            "throughput_boost_pct": tp_gain_pct,
            "energy_saved_pct": energy_saved_pct,
            "latency_reduction_pct": latency_reduction_pct,
            "p99_latency_reduction_pct": p99_latency_reduction_pct,
            "packet_drop_reduction_pct": drop_reduction_pct,
            "cell_edge_sinr_gain_db": edge_sinr_gain_db,
            "co2_emissions_avoided_kg": co2_saved_kg,
            "kwh_saved": round(leg_kpis["total_energy_kwh"] - ai_kpis["total_energy_kwh"], 1)
        }

        # Step by step time-series for frontend visual overlay (sample every 2 steps = 30m)
        timeline_series = []
        for i in range(0, len(legacy_history), 2):
            leg_item = legacy_history[i]
            ai_item = ai_history[i]
            hour = leg_item["hour"]

            leg_tp = sum(c["throughput_mbps"] for c in leg_item["telemetry"].values())
            ai_tp = sum(c["throughput_mbps"] for c in ai_item["telemetry"].values())

            leg_pw = sum(c["power_watts"] for c in leg_item["telemetry"].values())
            ai_pw = sum(c["power_watts"] for c in ai_item["telemetry"].values())

            timeline_series.append({
                "hour": hour,
                "legacy_throughput_mbps": round(leg_tp, 1),
                "ai_throughput_mbps": round(ai_tp, 1),
                "legacy_power_watts": round(leg_pw, 1),
                "ai_power_watts": round(ai_pw, 1),
            })

        return {
            "simulation_steps": self.steps,
            "legacy_kpis": leg_kpis,
            "ai_kpis": ai_kpis,
            "summary_scorecard": summary_scorecard,
            "timeline_series": timeline_series,
        }


if __name__ == "__main__":
    print("Running 24-Hour Benchmark Simulation...")
    engine = BenchmarkEngine(steps=48)
    report = engine.run_benchmark()
    score = report["summary_scorecard"]
    print("\n--- BENCHMARK RESULTS ---")
    print(f"Throughput Uplift:       +{score['throughput_boost_pct']}%")
    print(f"Energy Savings:          {score['energy_saved_pct']}% saved ({score['kwh_saved']} kWh saved)")
    print(f"Latency Reduction:       {score['latency_reduction_pct']}% (p99 latency: {score['p99_latency_reduction_pct']}%)")
    print(f"Packet Drop Reduction:   {score['packet_drop_reduction_pct']}%")
    print(f"Cell-Edge SINR Gain:     +{score['cell_edge_sinr_gain_db']} dB")
    print(f"CO2 Avoided:             {score['co2_emissions_avoided_kg']} kg")
