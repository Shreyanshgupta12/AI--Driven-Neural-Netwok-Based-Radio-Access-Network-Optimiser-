"""
Capacity Optimization & Proactive Congestion Guard Module 📊
Predicts impending cell capacity exhaustion 15-30 minutes ahead.
Automatically triggers proactive traffic steering, Cell Individual Offset (CIO)
tuning, and edge UE handovers to underutilized neighbor cells before packet drops happen.
"""

from typing import Dict, List, Tuple
from core.simulator.network_sim import NetworkSimulator, UserEquipment


class CapacityGuard:
    """
    Capacity & Congestion Management Engine.
    Monitors cell load trajectories, computes congestion probability,
    and executes proactive load balancing across neighboring cells.
    """

    def __init__(self, capacity_limit_ues: int = 80, congestion_threshold: float = 0.85):
        self.capacity_limit_ues = capacity_limit_ues
        self.congestion_threshold = congestion_threshold  # 85% load threshold

    def evaluate_congestion_risk(
        self,
        cell_id: str,
        current_telemetry: Dict,
        predicted_demand: Dict
    ) -> Dict:
        """
        Calculates congestion risk index (0.0 to 1.0) and time-to-saturation (minutes).
        """
        curr_ues = current_telemetry.get("active_ues", 20)
        curr_load = current_telemetry.get("load_ratio", 0.3)
        pred_ues_15m = predicted_demand.get("predicted_ues_15m", curr_ues)
        pred_ues_1h = predicted_demand.get("predicted_ues_1h", curr_ues)

        # Rate of user influx (UEs per minute)
        ue_delta_per_min = (pred_ues_15m - curr_ues) / 15.0

        # Estimated time until 85% capacity threshold
        remaining_headroom = max(0, int(self.capacity_limit_ues * self.congestion_threshold) - curr_ues)
        if ue_delta_per_min > 0.05:
            minutes_to_congestion = round(remaining_headroom / ue_delta_per_min, 1)
        else:
            minutes_to_congestion = 999.0  # Safe

        # Congestion risk probability score
        load_score = curr_load / self.congestion_threshold
        pred_score = pred_ues_15m / self.capacity_limit_ues
        risk_score = round(min(1.0, max(0.0, 0.4 * load_score + 0.6 * pred_score)), 3)

        risk_level = "CRITICAL" if risk_score >= 0.85 else (
            "WARNING" if risk_score >= 0.65 else "HEALTHY"
        )

        return {
            "cell_id": cell_id,
            "current_ues": curr_ues,
            "capacity_limit": self.capacity_limit_ues,
            "current_load_pct": round(curr_load * 100, 1),
            "predicted_ues_15m": pred_ues_15m,
            "minutes_to_congestion": minutes_to_congestion if minutes_to_congestion < 120 else "No Risk (>2h)",
            "congestion_risk_score": risk_score,
            "risk_level": risk_level,
            "action_required": risk_level in ["CRITICAL", "WARNING"]
        }

    def execute_proactive_traffic_steering(
        self,
        sim: NetworkSimulator,
        source_cell_id: str,
        target_cell_id: str,
        max_ues_to_steer: int = 15
    ) -> Dict:
        """
        Executes proactive mobility load balancing:
        Finds UEs on the boundary of source_cell_id that can be safely served by target_cell_id,
        and migrates their RRC connections via Handover Margin / CIO adjustment.
        """
        source_cell = sim.cells.get(source_cell_id)
        target_cell = sim.cells.get(target_cell_id)
        
        if not source_cell or not target_cell:
            return {"steered_count": 0, "message": "Invalid cell specified"}

        # Find eligible boundary UEs with handover candidates
        candidates = []
        for uid, ue in source_cell.connected_ues.items():
            if ue.handover_candidate == target_cell_id:
                candidates.append(ue)

        # If not enough explicitly flagged, check distance boundary
        if len(candidates) < max_ues_to_steer:
            for uid, ue in source_cell.connected_ues.items():
                if ue not in candidates:
                    d_target = ((ue.x - target_cell.x)**2 + (ue.y - target_cell.y)**2)**0.5
                    if d_target < 650.0:  # Within target cell's viable coverage
                        candidates.append(ue)

        # Select up to max_ues_to_steer
        steered_ues = candidates[:max_ues_to_steer]
        
        # Execute migration
        for ue in steered_ues:
            # Transfer UE from source to target cell
            del source_cell.connected_ues[ue.ue_id]
            ue.cell_id = target_cell_id
            ue.handover_candidate = None
            target_cell.connected_ues[ue.ue_id] = ue

        # Recalculate channels post-handover
        sim.update_radio_channels()

        return {
            "source_cell": source_cell_id,
            "target_cell": target_cell_id,
            "steered_count": len(steered_ues),
            "source_ues_remaining": len(source_cell.connected_ues),
            "target_ues_now": len(target_cell.connected_ues),
            "congestion_mitigated": len(steered_ues) > 0,
            "status_message": f"Successfully migrated {len(steered_ues)} edge UEs from {source_cell_id} to {target_cell_id}."
        }
