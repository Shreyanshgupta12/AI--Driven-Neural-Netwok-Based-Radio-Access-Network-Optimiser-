"""
Traffic Optimization & Demand Predictor Module
Predicts future cell-level PRB requirements, active UE counts, and throughput.
Forms the foundation: AI/ML -> Traffic Prediction -> Resource Optimization -> Better Network Performance.
"""

from typing import Dict, List, Tuple
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor


class TrafficPredictor:
    """
    Supervised Machine Learning model for forecasting multi-cell RAN traffic.
    Predicts PRB utilization and connected user demand for the upcoming 15-min and 60-min horizons.
    """

    def __init__(self):
        self.is_trained = False
        self.models: Dict[str, GradientBoostingRegressor] = {}
        self.history_buffer: Dict[str, List[Dict]] = {"Cell_A": [], "Cell_B": [], "Cell_C": []}
        self._pretrain_default_models()

    def _generate_synthetic_telemetry(self, days: int = 14) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
        """
        Generates 14 days of realistic cell telemetry with diurnal peaks,
        rush hours, weekend shifts, and occasional stadium surges.
        """
        samples = days * 24 * 4  # 15-min intervals
        X = []
        y = {"Cell_A": [], "Cell_B": [], "Cell_C": []}

        for i in range(samples):
            step = i % (24 * 4)
            hour = (step * 0.25)
            day_of_week = (i // (24 * 4)) % 7
            is_weekend = 1.0 if day_of_week >= 5 else 0.0

            # Diurnal base curves
            base_a = 50 + 45 * np.sin(np.pi * (hour - 6) / 12) ** 2
            base_b = 30 + 55 * np.sin(np.pi * (hour - 14) / 10) ** 2  # Residential evening peak
            base_c = 40 + 50 * (1.0 if (8 <= hour <= 18 and not is_weekend) else 0.15)  # Tech park work hours

            # Night lull
            if 2.0 <= hour <= 5.0:
                base_a *= 0.25
                base_b *= 0.20
                base_c *= 0.10

            # Weekend shift
            if is_weekend:
                base_a *= 1.2  # shopping / leisure
                base_b *= 1.3
                base_c *= 0.2

            # Noise and occasional event spikes
            noise_a = np.random.normal(0, 4)
            noise_b = np.random.normal(0, 3)
            noise_c = np.random.normal(0, 3)

            # Stadium surge on Friday evening (sample index check)
            if day_of_week == 4 and 19.0 <= hour <= 22.0 and i > samples * 0.7:
                base_a += 40.0

            val_a = max(5.0, min(120.0, base_a + noise_a))
            val_b = max(4.0, min(100.0, base_b + noise_b))
            val_c = max(3.0, min(90.0, base_c + noise_c))

            features = [
                hour,
                np.sin(2 * np.pi * hour / 24),
                np.cos(2 * np.pi * hour / 24),
                day_of_week,
                is_weekend,
            ]
            X.append(features)
            y["Cell_A"].append(val_a)
            y["Cell_B"].append(val_b)
            y["Cell_C"].append(val_c)

        return np.array(X), {k: np.array(v) for k, v in y.items()}

    def _pretrain_default_models(self):
        """Train models on synthetic historical multi-cell traffic dataset."""
        X, y_dict = self._generate_synthetic_telemetry(days=14)
        for cell_id, y in y_dict.items():
            gbr = GradientBoostingRegressor(
                n_estimators=75,
                learning_rate=0.08,
                max_depth=4,
                random_state=42
            )
            gbr.fit(X, y)
            self.models[cell_id] = gbr
        self.is_trained = True

    def extract_features(self, hour: float, recent_loads: List[float]) -> np.ndarray:
        """Transforms current operational context into feature vector."""
        # Assume weekday default or infer from history
        sin_hour = np.sin(2 * np.pi * hour / 24)
        cos_hour = np.cos(2 * np.pi * hour / 24)
        day_of_week = 2.0  # Default Wednesday
        is_weekend = 0.0
        return np.array([[hour, sin_hour, cos_hour, day_of_week, is_weekend]])

    def predict_demand(self, current_hour: float, current_telemetry: Dict[str, Dict]) -> Dict[str, Dict]:
        """
        Forecasts the expected traffic demand (UE count & PRB demand)
        for the upcoming 15-minute and 60-minute time intervals.
        """
        predictions = {}
        for cell_id, cell_data in current_telemetry.items():
            features_now = self.extract_features(current_hour, [cell_data["load_ratio"]])
            features_next_1h = self.extract_features((current_hour + 1.0) % 24.0, [cell_data["load_ratio"]])

            model = self.models.get(cell_id)
            if model:
                pred_ues_15m = float(model.predict(features_now)[0])
                pred_ues_1h = float(model.predict(features_next_1h)[0])
            else:
                pred_ues_15m = cell_data["active_ues"] * 1.05
                pred_ues_1h = cell_data["active_ues"] * 1.10

            # Blend with recent real-time observation (exponential smoothing)
            current_ues = cell_data["active_ues"]
            blended_15m = round(0.4 * current_ues + 0.6 * pred_ues_15m, 1)
            blended_1h = round(0.2 * current_ues + 0.8 * pred_ues_1h, 1)

            # Estimate required PRBs: average UE needs ~3.5 to 5 PRBs depending on service mix
            prbs_needed_15m = int(min(450, max(20, blended_15m * 4.2)))
            prbs_needed_1h = int(min(450, max(20, blended_1h * 4.2)))

            # Anomaly / surge detection
            anomaly_detected = False
            if current_ues > blended_15m * 1.5 and current_ues > 50:
                anomaly_detected = True

            predictions[cell_id] = {
                "current_ues": current_ues,
                "predicted_ues_15m": blended_15m,
                "predicted_ues_1h": blended_1h,
                "predicted_prbs_15m": prbs_needed_15m,
                "predicted_prbs_1h": prbs_needed_1h,
                "surge_anomaly_detected": anomaly_detected,
                "demand_trend": "increasing" if blended_1h > current_ues * 1.1 else (
                    "decreasing" if blended_1h < current_ues * 0.9 else "stable"
                ),
            }

        return predictions
