"""
Scheduling Optimization Module 📅
AI-Native MAC Layer Packet and Physical Resource Block (PRB) Scheduler.
Considers Channel Quality (CQI), Head-of-Line Delay, QoS Class Identifier (QCI),
and URLLC latency deadlines to dynamically schedule UEs.
Directly compares against traditional Round Robin (RR) and Proportional Fair (PF).
"""

import math
from typing import Dict, List, Tuple
import numpy as np
from core.simulator.network_sim import UserEquipment, TrafficType, CQI_TABLE


class IntelligentScheduler:
    """
    Intelligent Multi-User MAC Scheduler for 5G NR.
    Ranks competing users using an ML-optimized multi-objective utility function
    that balances throughput, fairness, and delay constraints.
    """

    def __init__(self):
        # Default policy weights learned via Reinforcement Learning / Policy Search
        self.w_spectral = 1.2      # Channel efficiency
        self.w_delay_urgency = 2.8  # Latency deadline proximity (exponential exponent)
        self.w_qos_priority = 2.0   # Traffic class weight (URLLC vs eMBB vs mMTC)
        self.delay_exponent = 2.2

    def schedule_round_robin(self, ues: List[UserEquipment], total_prbs: int) -> Dict[int, int]:
        """Baseline 1: Pure Round Robin (Equal PRB distribution)."""
        if not ues:
            return {}
        prbs_each = max(1, total_prbs // len(ues))
        allocation = {}
        rem = total_prbs
        for ue in ues:
            take = min(rem, prbs_each)
            allocation[ue.ue_id] = take
            rem -= take
        return allocation

    def schedule_proportional_fair(self, ues: List[UserEquipment], total_prbs: int) -> Dict[int, int]:
        """Baseline 2: Standard Proportional Fair (R_i / avg_R_i)."""
        if not ues:
            return {}
        # PF Metric = Instantaneous achievable rate / Historical average rate
        scores = {}
        for ue in ues:
            spec_eff = CQI_TABLE[ue.cqi][4]
            r_inst = spec_eff * 360e3  # Rate per PRB
            r_avg = max(1.0, ue.served_throughput_mbps * 1e6)
            scores[ue.ue_id] = r_inst / (r_avg ** 0.6)

        # Allocate PRBs proportionally to PF score
        total_score = sum(scores.values())
        allocation = {}
        rem = total_prbs
        for ue in ues:
            share = int(round((scores[ue.ue_id] / max(1e-5, total_score)) * total_prbs))
            assigned = max(1, min(rem, share))
            allocation[ue.ue_id] = assigned
            rem -= assigned

        # Distribute leftover
        if rem > 0 and ues:
            top_ue = max(scores, key=scores.get)
            allocation[top_ue] += rem

        return allocation

    def schedule_ai_native(self, ues: List[UserEquipment], total_prbs: int) -> Dict[int, int]:
        """
        AI-Native Scheduler:
        Computes composite reward score combining:
        1. Spectral Efficiency (CQI)
        2. Delay Urgency: (QueueDelay / MaxLatency)^gamma -> spikes to infinity as SLA expires!
        3. QoS Traffic Priority (URLLC = 4.0, eMBB = 1.0, mMTC = 0.5)
        4. Buffer backlog demand
        """
        if not ues:
            return {}

        scores = {}
        for ue in ues:
            spec_eff = CQI_TABLE[ue.cqi][4]
            
            # Latency urgency ratio (critical for URLLC < 5ms)
            delay_ratio = min(1.5, ue.queue_delay_ms / max(1.0, ue.max_latency_ms))
            delay_penalty = (delay_ratio ** self.delay_exponent) * self.w_delay_urgency

            # Backlog factor (diminishing return for empty buffers)
            buffer_mb = ue.buffer_bytes * 8 / 1e6
            buffer_urgency = math.log1p(buffer_mb)

            # Combined AI Utility Score
            score = (
                (self.w_spectral * spec_eff) +
                delay_penalty +
                (self.w_qos_priority * ue.priority_weight) +
                (0.5 * buffer_urgency)
            )
            scores[ue.ue_id] = max(0.1, score)

        # Dynamic Water-Filling PRB Allocation
        total_score = sum(scores.values())
        allocation = {}
        rem = total_prbs
        
        # Sort UEs by priority score descending
        sorted_ues = sorted(ues, key=lambda u: scores[u.ue_id], reverse=True)
        
        for ue in sorted_ues:
            # High priority URLLC gets exact PRBs to flush queue immediately
            spec_eff = CQI_TABLE[ue.cqi][4]
            prb_cap_mbps = (spec_eff * 360e3) / 1e6
            prbs_to_flush = int(np.ceil((ue.buffer_bytes * 8 / 1e6) / max(0.01, prb_cap_mbps)))
            
            # Score proportional share
            proportional_share = int((scores[ue.ue_id] / max(1e-5, total_score)) * total_prbs)
            
            if ue.traffic_type == TrafficType.URLLC:
                # Guarantee queue clearing for URLLC to meet strict <5ms SLA
                assigned = min(rem, max(2, prbs_to_flush))
            else:
                # eMBB / mMTC: allocate proportional share, capped at buffer demand + 20% burst headroom
                max_useful_prbs = max(2, int(prbs_to_flush * 1.25))
                assigned = min(rem, min(max_useful_prbs, max(1, proportional_share)))
                
            allocation[ue.ue_id] = assigned
            rem -= assigned
            if rem <= 0:
                break

        # Any remaining PRBs are intentionally left unallocated to enable
        # base station slot-level micro-sleep (saving RF amplifier energy)

        # Ensure all UEs have an entry
        for ue in ues:
            if ue.ue_id not in allocation:
                allocation[ue.ue_id] = 0

        return allocation

    def benchmark_schedulers(self, ues: List[UserEquipment], total_prbs: int) -> Dict[str, Dict]:
        """
        Runs simulated subframe on all 3 schedulers and compares:
        - Total Throughput (Mbps)
        - URLLC Average Delay (ms)
        - URLLC SLA Violation Count
        - Fairness Index (Jain's Fairness Index)
        """
        import copy
        results = {}

        for mode, func in [
            ("Round_Robin", self.schedule_round_robin),
            ("Proportional_Fair", self.schedule_proportional_fair),
            ("AI_Native", self.schedule_ai_native)
        ]:
            ue_copies = [copy.deepcopy(u) for u in ues]
            alloc = func(ue_copies, total_prbs)
            
            tot_tp = 0.0
            urllc_delays = []
            sla_violations = 0
            throughputs = []

            for u in ue_copies:
                prbs = alloc.get(u.ue_id, 0)
                spec_eff = CQI_TABLE[u.cqi][4]
                rate_mbps = (prbs * 360e3 * spec_eff) / 1e6
                served = min(rate_mbps, u.buffer_bytes * 8 / 1e6)
                throughputs.append(served)
                tot_tp += served

                # Delay evaluation
                if u.traffic_type == TrafficType.URLLC:
                    post_delay = u.queue_delay_ms if served >= u.buffer_bytes * 8 / 1e6 else (u.queue_delay_ms + 4.0)
                    urllc_delays.append(post_delay)
                    if post_delay > u.max_latency_ms:
                        sla_violations += 1

            # Jain's fairness index: (sum x)^2 / (n * sum x^2)
            n = len(throughputs)
            sum_x = sum(throughputs)
            sum_sq_x = sum(x**2 for x in throughputs)
            jain = (sum_x ** 2) / (n * sum_sq_x) if (n > 0 and sum_sq_x > 0) else 1.0

            results[mode] = {
                "total_throughput_mbps": round(tot_tp, 2),
                "urllc_avg_delay_ms": round(float(np.mean(urllc_delays)), 2) if urllc_delays else 0.0,
                "sla_violations": sla_violations,
                "jains_fairness_index": round(jain, 3)
            }

        return results
