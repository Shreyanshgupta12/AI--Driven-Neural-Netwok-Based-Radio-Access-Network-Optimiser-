"""
Spectrum Optimization Module 📡
Dynamically allocates radio frequency resources (Physical Resource Blocks - PRBs)
across cells based on predicted traffic demand, channel quality, and interference.
Replaces static 33/33/33 partitioning with an elastic, demand-driven shared spectrum pool.
"""

from typing import Dict, Tuple
import numpy as np


class SpectrumOptimizer:
    """
    ML-driven Dynamic Spectrum and PRB Allocator.
    Dynamically pools and reallocates 5G NR carrier bandwidth
    to ensure high-traffic cells never starve while maintaining minimum QoS across all cells.
    """

    def __init__(self, total_shared_prbs: int = 819, min_prb_guarantee: int = 50):
        # 3 cells x 273 PRBs = 819 total PRBs in 100 MHz cluster pool
        self.total_shared_prbs = total_shared_prbs
        self.min_prb_guarantee = min_prb_guarantee  # Guarantees no cell completely starves

    def optimize_spectrum_allocation(
        self,
        predicted_demands: Dict[str, Dict],
        current_telemetry: Dict[str, Dict]
    ) -> Dict[str, Dict]:
        """
        Solves the constrained dynamic spectrum allocation problem:
        Maximize overall cluster utility while satisfying:
        sum(allocated_prbs) <= total_shared_prbs
        allocated_prbs[cell] >= min_prb_guarantee
        """
        cell_weights = {}
        total_weight = 0.0

        for cell_id, pred in predicted_demands.items():
            telemetry = current_telemetry.get(cell_id, {})
            # Weight is driven by predicted PRB need, with bonus if current load is already near capacity
            pred_prbs = pred["predicted_prbs_15m"]
            current_load = telemetry.get("load_ratio", 0.5)
            avg_sinr = telemetry.get("avg_sinr_db", 14.0)

            # Higher CQI / SINR gives better spectral efficiency, so allocating PRBs there yields high throughput,
            # but priority must also alleviate bottlenecked cells (water-filling utility).
            load_stress_factor = 1.0 + (current_load ** 2) * 1.5
            effective_demand = pred_prbs * load_stress_factor

            cell_weights[cell_id] = effective_demand
            total_weight += effective_demand

        # Allocate PRBs
        allocations = {}
        available_elastic_prbs = self.total_shared_prbs - (len(predicted_demands) * self.min_prb_guarantee)
        
        prb_sum_check = 0
        for cell_id, weight in cell_weights.items():
            elastic_share = (weight / max(1.0, total_weight)) * available_elastic_prbs
            allocated = int(self.min_prb_guarantee + round(elastic_share))
            allocations[cell_id] = allocated
            prb_sum_check += allocated

        # Fine-tune rounding difference
        diff = self.total_shared_prbs - prb_sum_check
        if diff != 0:
            top_cell = max(cell_weights, key=cell_weights.get)
            allocations[top_cell] += diff

        # Compare with legacy static allocation (273 PRBs each)
        results = {}
        for cell_id, allocated in allocations.items():
            pred_needed = predicted_demands[cell_id]["predicted_prbs_15m"]
            static_prbs = 273
            
            # Static satisfaction vs AI satisfaction
            static_satisfaction = min(1.0, static_prbs / max(1, pred_needed))
            ai_satisfaction = min(1.0, allocated / max(1, pred_needed))

            spectral_gain_pct = round(((ai_satisfaction - static_satisfaction) / max(0.01, static_satisfaction)) * 100, 1)

            results[cell_id] = {
                "allocated_prbs": allocated,
                "static_baseline_prbs": static_prbs,
                "prb_difference": allocated - static_prbs,
                "demand_prbs_predicted": pred_needed,
                "spectrum_utilization_ratio": round(min(1.0, pred_needed / allocated), 2),
                "satisfaction_rate_ai": round(ai_satisfaction * 100, 1),
                "satisfaction_rate_static": round(static_satisfaction * 100, 1),
                "spectral_gain_pct": spectral_gain_pct,
                "action_summary": (
                    f"Boosted +{allocated - static_prbs} PRBs (High Demand)" if allocated > static_prbs else (
                        f"Donated {static_prbs - allocated} PRBs to pool (Low Demand)" if allocated < static_prbs else "Balanced"
                    )
                )
            }

        return results
