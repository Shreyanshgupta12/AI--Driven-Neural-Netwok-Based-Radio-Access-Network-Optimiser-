"""
Unified AI-RAN Closed-Loop Orchestrator
Coordinates the 6 ML Optimization Pillars with the 5G NR Simulator.
Implements the core Nokia AI-RAN paradigm:
AI/ML -> Traffic Prediction -> Resource Optimization -> Better Network Performance.
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from typing import Dict, List, Optional
import numpy as np
from core.simulator.network_sim import NetworkSimulator, PowerState, TrafficType, CQI_TABLE
from core.models.traffic_predictor import TrafficPredictor
from core.models.spectrum_optimizer import SpectrumOptimizer
from core.models.energy_saver import EnergySaver
from core.models.scheduler import IntelligentScheduler
from core.models.capacity_guard import CapacityGuard
from core.models.interference_mitigator import InterferenceMitigator


class AIRANOrchestrator:
    """
    Central Controller for Nokia AI-RAN platform.
    Runs either in 'AI_ENABLED' mode (all 6 ML pillars active)
    or 'LEGACY_BASELINE' mode (static PRBs, static full power, basic PF scheduling, no proactive steering).
    """

    def __init__(self, mode: str = "AI_ENABLED"):
        self.mode = mode
        self.sim = NetworkSimulator(seed=42)
        
        # Initialize the 6 ML modules
        self.traffic_predictor = TrafficPredictor()
        self.spectrum_optimizer = SpectrumOptimizer(total_shared_prbs=819, min_prb_guarantee=60)
        self.energy_saver = EnergySaver()
        self.scheduler = IntelligentScheduler()
        self.capacity_guard = CapacityGuard(capacity_limit_ues=80, congestion_threshold=0.82)
        self.interference_mitigator = InterferenceMitigator()

        # Telemetry and event logs
        self.step_history: List[Dict] = []
        self.event_log: List[Dict] = []

    def set_scenario(self, scenario_name: str):
        """Sets active traffic scenario: 'normal', 'rush_hour', 'stadium_surge', 'night_lull', 'rain_fade'."""
        self.sim.current_scenario = scenario_name
        self.event_log.append({
            "step": self.sim.time_step,
            "hour": round(self.sim.simulation_hour, 2),
            "type": "SCENARIO_CHANGE",
            "message": f"Applied network scenario: '{scenario_name}'."
        })

    def reset(self):
        """Resets simulator to clean state."""
        self.sim = NetworkSimulator(seed=42)
        self.step_history.clear()
        self.event_log.clear()

    def run_step(self) -> Dict:
        """
        Executes one discrete simulation time-step (15 minutes).
        Returns comprehensive telemetry and decisions from all 6 pillars.
        """
        # 1. Update traffic demand & spawn/retire UEs
        self.sim.step_traffic_demand()

        # 2. Update radio propagation channels
        self.sim.update_radio_channels()

        # 3. Snapshot raw telemetry before optimization
        current_telemetry = self.sim.get_cell_telemetry()

        if self.mode == "LEGACY_BASELINE":
            # Run traditional static baseline RAN
            self.sim.execute_baseline_scheduling()
            post_telemetry = self.sim.get_cell_telemetry()
            
            step_record = {
                "step": self.sim.time_step,
                "hour": round(self.sim.simulation_hour, 2),
                "mode": self.mode,
                "scenario": self.sim.current_scenario,
                "telemetry": post_telemetry,
                "ai_decisions": None,
                "summary": "Legacy Static RAN: Fixed PRBs, Constant 46 dBm Tx power, No AI steering."
            }
            self.step_history.append(step_record)
            return step_record

        # --- AI-ENABLED CLOSED LOOP OPTIMIZATION (THE 6 PILLARS) ---

        # PILLAR 1: Traffic Demand Prediction
        predicted_demands = self.traffic_predictor.predict_demand(
            self.sim.simulation_hour, current_telemetry
        )

        # PILLAR 5: Capacity Guard & Proactive Steering
        congestion_evals = {}
        steering_actions = []
        for cid, t_data in current_telemetry.items():
            eval_res = self.capacity_guard.evaluate_congestion_risk(
                cid, t_data, predicted_demands[cid]
            )
            congestion_evals[cid] = eval_res
            
            # If critical congestion predicted, steer users to neighbor
            if eval_res["action_required"]:
                # Pick neighbor with lowest load
                other_cells = [c for c in self.sim.cells if c != cid]
                best_target = min(other_cells, key=lambda c: self.sim.cells[c].current_load_ratio)
                if self.sim.cells[best_target].current_load_ratio < 0.65:
                    res = self.capacity_guard.execute_proactive_traffic_steering(
                        self.sim, source_cell_id=cid, target_cell_id=best_target, max_ues_to_steer=12
                    )
                    steering_actions.append(res)
                    if res["steered_count"] > 0:
                        self.event_log.append({
                            "step": self.sim.time_step,
                            "hour": round(self.sim.simulation_hour, 2),
                            "type": "TRAFFIC_STEERING",
                            "message": f"Steered {res['steered_count']} UEs from {cid} to {best_target} to prevent congestion."
                        })

        # PILLAR 2: Spectrum & PRB Optimization
        spectrum_results = self.spectrum_optimizer.optimize_spectrum_allocation(
            predicted_demands, current_telemetry
        )
        # Apply allocated PRBs to cells
        for cid, spec_data in spectrum_results.items():
            self.sim.cells[cid].allocated_prbs = spec_data["allocated_prbs"]

        # PILLAR 6: Interference Optimization (CoMP / eICIC)
        interference_analysis = self.interference_mitigator.analyze_interference_hotspots(self.sim)
        interference_results = self.interference_mitigator.optimize_interference_coordination(
            self.sim, mitigation_strategy="ai_coordinated_comp"
        )

        # PILLAR 3: Power Optimization (Energy Saver)
        energy_results = {}
        for cid, cell in self.sim.cells.items():
            has_urllc = any(u.traffic_type == TrafficType.URLLC for u in cell.connected_ues.values())
            e_eval = self.energy_saver.evaluate_energy_policy(
                cid, predicted_demands[cid], current_telemetry.get(cid, {}), has_urllc_active=has_urllc
            )
            energy_results[cid] = e_eval
            
            # Apply recommended state and Tx power
            cell.power_state = PowerState(e_eval["recommended_state"])
            cell.active_tx_power_dbm = e_eval["recommended_tx_dbm"]

        # Recalculate radio channels with AI beamforming & optimized powers
        self.sim.update_radio_channels(ai_beamforming_active=True)

        # PILLAR 4: Intelligent MAC Scheduling
        scheduling_results = {}
        for cid, cell in self.sim.cells.items():
            active_ues = list(cell.connected_ues.values())
            if not active_ues:
                cell.current_load_ratio = 0.0
                cell.throughput_mbps = 0.0
                cell.avg_latency_ms = 1.0
                cell.packet_loss_rate = 0.0
                cell.instantaneous_power_w = round(cell.compute_power_consumption(0.0), 1)
                continue

            # Benchmark schedulers for insights
            bench = self.scheduler.benchmark_schedulers(active_ues, cell.allocated_prbs)
            scheduling_results[cid] = bench

            # Apply AI-Native scheduler assignments
            alloc = self.scheduler.schedule_ai_native(active_ues, cell.allocated_prbs)
            
            tot_tp = 0.0
            tot_lat = 0.0
            drops = 0
            for ue in active_ues:
                assigned_prbs = alloc.get(ue.ue_id, 0)
                ue.assigned_prbs = assigned_prbs
                spec_eff = CQI_TABLE[ue.cqi][4]
                rate_mbps = (assigned_prbs * 360e3 * spec_eff) / 1e6
                served = min(rate_mbps, ue.buffer_bytes * 8 / 1e6)
                
                ue.served_throughput_mbps = round(served, 2)
                tot_tp += served

                # Buffer update
                ue.buffer_bytes = max(0.0, ue.buffer_bytes - (served * 1e6 / 8))
                if ue.buffer_bytes > 0:
                    ue.queue_delay_ms += (ue.buffer_bytes / (max(0.1, served) * 1e6 / 8)) * 8
                else:
                    ue.queue_delay_ms = max(1.5, ue.queue_delay_ms * 0.5)

                if ue.queue_delay_ms > ue.max_latency_ms:
                    drops += 1
                    ue.dropped_packets += 1
                    ue.buffer_bytes *= 0.5

                tot_lat += ue.queue_delay_ms

            total_used_prbs = sum(ue.assigned_prbs for ue in active_ues)
            cell.current_load_ratio = round(min(1.0, total_used_prbs / max(1, cell.allocated_prbs)), 3)
            cell.throughput_mbps = round(tot_tp, 2)
            cell.avg_latency_ms = round(tot_lat / len(active_ues), 2)
            cell.packet_loss_rate = round(drops / max(1, len(active_ues)), 4)
            cell.instantaneous_power_w = round(cell.compute_power_consumption(cell.current_load_ratio), 1)
            cell.cumulative_energy_kwh += (cell.instantaneous_power_w * 0.25) / 1000.0

        post_telemetry = self.sim.get_cell_telemetry()

        step_record = {
            "step": self.sim.time_step,
            "hour": round(self.sim.simulation_hour, 2),
            "mode": self.mode,
            "scenario": self.sim.current_scenario,
            "telemetry": post_telemetry,
            "ai_decisions": {
                "traffic_predictions": predicted_demands,
                "spectrum_optimization": spectrum_results,
                "power_optimization": energy_results,
                "scheduling_benchmarks": scheduling_results,
                "capacity_congestion": congestion_evals,
                "steering_actions": steering_actions,
                "interference_analysis": interference_analysis,
                "interference_coordination": interference_results,
            },
            "summary": "AI-RAN Active: Dynamic PRB Pooling, Micro-Sleep & Tx Scaling, QoS Scheduling, CoMP Interference Mitigation."
        }
        self.step_history.append(step_record)
        return step_record
