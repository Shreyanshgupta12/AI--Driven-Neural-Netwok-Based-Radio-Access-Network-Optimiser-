"""
5G NR Multi-Cell Radio Access Network (RAN) Simulator
Models 3GPP physical layer propagation, PRB allocation, interference,
power states, user traffic queues, and channel quality.
"""

from dataclasses import dataclass, field
from enum import Enum
import math
import random
from typing import Dict, List, Optional, Tuple
import numpy as np


class TrafficType(Enum):
    EMBB = "eMBB"      # Enhanced Mobile Broadband (video, streaming, heavy data)
    URLLC = "URLLC"    # Ultra-Reliable Low-Latency (autonomous, medical, industrial)
    MMTC = "mMTC"      # Massive Machine-Type Communications (IoT, sensors)


class PowerState(Enum):
    ACTIVE_MAX = "active_max"            # 100% Tx power, all TRX active
    ACTIVE_DYNAMIC_PA = "active_dynamic" # Dynamic PA scaling based on active PRBs
    MICRO_SLEEP = "micro_sleep"          # Symbol/subframe muting (~40% power saved)
    LIGHT_SLEEP = "light_sleep"          # Carrier shutdown (~60% power saved)
    DEEP_SLEEP = "deep_sleep"            # Standby mode (~80% power saved)


# 3GPP TS 38.214 Table 5.2.2.1-2: 4-bit CQI Table (approximate SINR thresholds and spectral efficiencies)
CQI_TABLE = [
    # CQI: (Min SINR dB, Modulation, CodeRate x 1024, Spectral Efficiency bps/Hz)
    (0, -10.0, "Out of Range", 0, 0.0),
    (1, -6.0, "QPSK", 78, 0.1523),
    (2, -4.0, "QPSK", 120, 0.2344),
    (3, -2.0, "QPSK", 193, 0.3770),
    (4, 0.0, "QPSK", 308, 0.6016),
    (5, 2.0, "QPSK", 449, 0.8770),
    (6, 4.0, "QPSK", 602, 1.1758),
    (7, 6.0, "16QAM", 378, 1.4766),
    (8, 8.0, "16QAM", 490, 1.9141),
    (9, 10.0, "16QAM", 616, 2.4063),
    (10, 12.0, "64QAM", 466, 2.7305),
    (11, 14.0, "64QAM", 567, 3.3203),
    (12, 16.0, "64QAM", 666, 3.9023),
    (13, 18.0, "64QAM", 772, 4.5234),
    (14, 20.0, "256QAM", 711, 5.1152),
    (15, 22.0, "256QAM", 772, 5.5547),
]


@dataclass
class UserEquipment:
    ue_id: int
    cell_id: str
    x: float                     # meters relative to grid
    y: float                     # meters relative to grid
    traffic_type: TrafficType
    required_rate_mbps: float
    buffer_bytes: float = 0.0
    queue_delay_ms: float = 0.0
    max_latency_ms: float = 50.0  # URLLC target < 5-10ms, eMBB ~ 50ms
    priority_weight: float = 1.0
    cqi: int = 10
    sinr_db: float = 12.0
    assigned_prbs: int = 0
    served_throughput_mbps: float = 0.0
    dropped_packets: int = 0
    handover_candidate: Optional[str] = None
    shadowing_db: float = 0.0


@dataclass
class Cell:
    cell_id: str
    name: str
    x: float                     # meters
    y: float                     # meters
    carrier_freq_ghz: float = 3.5
    total_bandwidth_mhz: float = 100.0
    total_prbs: int = 273         # 100 MHz 5G NR numerology mu=1 (30 kHz SCS) has 273 PRBs
    allocated_prbs: int = 273     # Current PRB quota (can be dynamically shared)
    tx_power_dbm: float = 46.0   # Max BS Tx Power = 40 Watts (46 dBm)
    active_tx_power_dbm: float = 46.0
    power_state: PowerState = PowerState.ACTIVE_MAX
    num_trx: int = 64             # Massive MIMO 64T64R
    p_zero_watts: float = 120.0   # Static circuit power per TRX
    delta_p: float = 4.2          # Slope of load-dependent power
    p_sleep_watts: float = 15.0   # Base sleep power per TRX
    connected_ues: Dict[int, UserEquipment] = field(default_factory=dict)
    
    # Telemetry metrics
    current_load_ratio: float = 0.0
    instantaneous_power_w: float = 0.0
    cumulative_energy_kwh: float = 0.0
    throughput_mbps: float = 0.0
    avg_latency_ms: float = 0.0
    packet_loss_rate: float = 0.0
    avg_sinr_db: float = 0.0
    edge_sinr_db: float = 0.0     # 5th percentile SINR

    def compute_power_consumption(self, active_prb_ratio: float) -> float:
        """
        Calculates instantaneous power in Watts based on the EARTH energy model.
        """
        p_out_watts = 10 ** ((self.active_tx_power_dbm - 30) / 10)
        
        if self.power_state == PowerState.DEEP_SLEEP:
            # Standby circuitry only
            return self.num_trx * self.p_sleep_watts * 0.5
        elif self.power_state == PowerState.LIGHT_SLEEP:
            return self.num_trx * self.p_sleep_watts * 1.2
        elif self.power_state == PowerState.MICRO_SLEEP:
            # Power amplifier muted in empty symbols
            active_p = self.num_trx * (self.p_zero_watts * 0.7 + self.delta_p * p_out_watts * active_prb_ratio)
            return max(self.num_trx * self.p_sleep_watts * 2.0, active_p)
        elif self.power_state == PowerState.ACTIVE_DYNAMIC_PA:
            # Scale PA power proportional to active load
            scaled_p_out = p_out_watts * max(0.1, active_prb_ratio)
            return self.num_trx * (self.p_zero_watts + self.delta_p * scaled_p_out)
        else:  # ACTIVE_MAX
            return self.num_trx * (self.p_zero_watts + self.delta_p * p_out_watts)


class NetworkSimulator:
    """
    Complete 5G NR Multi-Cell Network Environment.
    Models 3 macro cells with varying characteristics:
    - Cell A: Urban Hotspot (High density, eMBB & URLLC)
    - Cell B: Suburban Residential (Diurnal shifts, evening streaming)
    - Cell C: Industrial / Enterprise Park (High URLLC, mMTC telemetry)
    """

    def __init__(self, seed: int = 42):
        np.random.seed(seed)
        random.seed(seed)
        self.time_step = 0
        self.simulation_hour = 8.0  # Starts at 08:00 AM
        self.current_scenario = "normal"
        self.weather_fade_db = 0.0

        # Initialize 3 cells on a coordinate plane
        self.cells: Dict[str, Cell] = {
            "Cell_A": Cell(cell_id="Cell_A", name="Central Urban Hub", x=0.0, y=0.0, tx_power_dbm=46.0),
            "Cell_B": Cell(cell_id="Cell_B", name="Suburban Residential", x=900.0, y=300.0, tx_power_dbm=46.0),
            "Cell_C": Cell(cell_id="Cell_C", name="Industrial Tech Park", x=450.0, y=950.0, tx_power_dbm=46.0),
        }
        
        self.next_ue_id = 1
        self.history_records: List[Dict] = []
        self._init_initial_ues()

    def _init_initial_ues(self):
        """Seed initial population of UEs across cells."""
        for cell_id, cell in self.cells.items():
            num_initial = 30 if cell_id == "Cell_A" else (20 if cell_id == "Cell_B" else 15)
            for _ in range(num_initial):
                self._spawn_ue_in_cell(cell_id)

    def _spawn_ue_in_cell(self, cell_id: str) -> UserEquipment:
        cell = self.cells[cell_id]
        # Distribute UEs with distance 20m to 550m from BS
        radius = np.random.uniform(20.0, 520.0)
        angle = np.random.uniform(0, 2 * math.pi)
        ue_x = cell.x + radius * math.cos(angle)
        ue_y = cell.y + radius * math.sin(angle)

        # Traffic mix based on cell profile
        if cell_id == "Cell_A":
            t_type = np.random.choice([TrafficType.EMBB, TrafficType.URLLC], p=[0.75, 0.25])
        elif cell_id == "Cell_B":
            t_type = np.random.choice([TrafficType.EMBB, TrafficType.MMTC], p=[0.85, 0.15])
        else:  # Cell_C
            t_type = np.random.choice([TrafficType.URLLC, TrafficType.EMBB, TrafficType.MMTC], p=[0.55, 0.25, 0.20])

        if t_type == TrafficType.URLLC:
            req_rate = np.random.uniform(2.0, 8.0)
            max_lat = 8.0
            weight = 4.0
        elif t_type == TrafficType.EMBB:
            req_rate = np.random.uniform(15.0, 60.0)
            max_lat = 60.0
            weight = 1.0
        else:  # mMTC
            req_rate = np.random.uniform(0.1, 1.5)
            max_lat = 200.0
            weight = 0.5

        ue = UserEquipment(
            ue_id=self.next_ue_id,
            cell_id=cell_id,
            x=ue_x,
            y=ue_y,
            traffic_type=t_type,
            required_rate_mbps=req_rate,
            buffer_bytes=req_rate * 1e6 / 8 * 0.1,  # initial buffer 100ms
            queue_delay_ms=np.random.uniform(1.0, 5.0),
            max_latency_ms=max_lat,
            priority_weight=weight,
            shadowing_db=float(np.random.normal(0, 2.5))
        )
        self.next_ue_id += 1
        cell.connected_ues[ue.ue_id] = ue
        return ue

    def compute_pathloss_db(self, dist_m: float, freq_ghz: float, shadowing_db: float = 0.0) -> float:
        """
        3GPP TR 38.901 Urban Macro (UMa) Line-of-Sight / Non-Line-of-Sight pathloss.
        d3D >= 10m
        """
        d = max(10.0, dist_m)
        pl = 28.0 + 22.0 * math.log10(d) + 20.0 * math.log10(freq_ghz)
        return pl + shadowing_db + self.weather_fade_db

    def update_radio_channels(self, ai_beamforming_active: bool = False):
        """
        Calculates RSRP, interference from adjacent cells, SINR, and CQI for every active UE.
        In AI-RAN mode, real-time AI algorithms at radio silicon apply Massive MIMO
        directional beamforming (+3.5 dB gain) and spatial interference nulling.
        """
        # Noise floor for 1 PRB (360 kHz = 12 subcarriers * 30 kHz)
        # N_PRB = -174 dBm/Hz + 10*log10(360,000) + 7 dB NF ~= -111.4 dBm
        noise_prb_w = 10 ** ((-111.4 - 30) / 10)

        for cell_id, cell in self.cells.items():
            sinrs = []
            for ue_id, ue in cell.connected_ues.items():
                # Desired signal
                d_desired = math.hypot(ue.x - cell.x, ue.y - cell.y)
                pl_desired = self.compute_pathloss_db(d_desired, cell.carrier_freq_ghz, ue.shadowing_db)
                rx_power_dbm = cell.active_tx_power_dbm - pl_desired
                if ai_beamforming_active and cell.power_state != PowerState.DEEP_SLEEP:
                    # Directional beamforming array gain on desired user
                    rx_power_dbm += 3.5
                rx_power_w = 10 ** ((rx_power_dbm - 30) / 10)

                # Interference from other 2 cells
                interf_w = 0.0
                closest_neighbor_id = None
                best_neighbor_sinr = -999.0

                for other_id, other_cell in self.cells.items():
                    if other_id == cell_id:
                        continue
                    
                    d_other = math.hypot(ue.x - other_cell.x, ue.y - other_cell.y)
                    pl_other = self.compute_pathloss_db(d_other, other_cell.carrier_freq_ghz, ue.shadowing_db)
                    other_rx_dbm = other_cell.active_tx_power_dbm - pl_other
                    other_rx_w = 10 ** ((other_rx_dbm - 30) / 10)
                    
                    # Spatial nulling in AI-RAN mode reduces cross-cell spill
                    if ai_beamforming_active:
                        other_rx_w *= 0.35

                    # If other cell is sleeping, interference drops significantly
                    if other_cell.power_state in (PowerState.DEEP_SLEEP, PowerState.LIGHT_SLEEP):
                        other_rx_w *= 0.05
                    elif other_cell.power_state == PowerState.MICRO_SLEEP:
                        other_rx_w *= 0.40
                    
                    interf_w += other_rx_w

                    # Check potential handover candidate
                    sinr_cand = other_rx_dbm - pl_other
                    if sinr_cand > best_neighbor_sinr:
                        best_neighbor_sinr = sinr_cand
                        closest_neighbor_id = other_id

                # Total SINR
                sinr_linear = rx_power_w / (interf_w + noise_prb_w)
                sinr_db = 10.0 * math.log10(max(1e-6, sinr_linear))
                sinrs.append(sinr_db)

                ue.sinr_db = round(sinr_db, 2)

                # Determine CQI (1 to 15)
                ue_cqi = 1
                for cqi_val, min_sinr, mod, cr, spec_eff in CQI_TABLE:
                    if sinr_db >= min_sinr:
                        ue_cqi = cqi_val
                ue.cqi = ue_cqi

                # Handover flagging if edge user
                if d_desired > 380 and closest_neighbor_id:
                    ue.handover_candidate = closest_neighbor_id
                else:
                    ue.handover_candidate = None

            if sinrs:
                cell.avg_sinr_db = round(float(np.mean(sinrs)), 2)
                cell.edge_sinr_db = round(float(np.percentile(sinrs, 5)), 2)
            else:
                cell.avg_sinr_db = 18.0
                cell.edge_sinr_db = 8.0

    def step_traffic_demand(self):
        """
        Advances the time of day and injects traffic based on diurnal patterns
        or active scenarios.
        """
        self.time_step += 1
        # Advance clock by 0.25 hours (15 min intervals)
        self.simulation_hour = (self.simulation_hour + 0.25) % 24.0

        # Base diurnal traffic multiplier (peak at 13h and 20h, valley at 3-5h)
        h = self.simulation_hour
        diurnal_factor = 0.5 + 0.5 * math.sin(math.pi * (h - 6) / 12) ** 2
        if 2.0 <= h <= 5.0:
            diurnal_factor *= 0.35  # Night drop

        # Apply Scenarios
        scenario_multiplier = {"Cell_A": 1.0, "Cell_B": 1.0, "Cell_C": 1.0}
        
        if self.current_scenario == "rush_hour":
            scenario_multiplier["Cell_A"] = 2.4  # Dense traffic congestion in Downtown
            scenario_multiplier["Cell_B"] = 1.1
            scenario_multiplier["Cell_C"] = 1.3
        elif self.current_scenario == "stadium_surge":
            scenario_multiplier["Cell_A"] = 3.2  # Massive flash crowd surge
            scenario_multiplier["Cell_B"] = 0.7
            scenario_multiplier["Cell_C"] = 0.6
        elif self.current_scenario == "night_lull":
            scenario_multiplier["Cell_A"] = 0.2
            scenario_multiplier["Cell_B"] = 0.3
            scenario_multiplier["Cell_C"] = 0.1
        elif self.current_scenario == "rain_fade":
            self.weather_fade_db = 6.0
        else:
            self.weather_fade_db = 0.0

        # Adjust UE population per cell
        for cell_id, cell in self.cells.items():
            base_target = 35 if cell_id == "Cell_A" else (25 if cell_id == "Cell_B" else 20)
            target_ues = int(base_target * diurnal_factor * scenario_multiplier[cell_id])
            target_ues = max(3, min(120, target_ues))

            current_count = len(cell.connected_ues)
            if current_count < target_ues:
                for _ in range(target_ues - current_count):
                    self._spawn_ue_in_cell(cell_id)
            elif current_count > target_ues:
                # Remove random UEs that finished transmission
                remove_ids = random.sample(list(cell.connected_ues.keys()), current_count - target_ues)
                for uid in remove_ids:
                    del cell.connected_ues[uid]

            # Influx into UE buffers
            for ue in cell.connected_ues.values():
                # Add packets for 15 seconds aggregated window
                added_mb = (ue.required_rate_mbps * random.uniform(0.8, 1.2)) * 0.5
                ue.buffer_bytes += added_mb * 1e6 / 8

    def execute_baseline_scheduling(self):
        """
        Legacy Baseline RAN:
        - Fixed static PRBs (equal split, 273 PRBs per cell).
        - Fixed full Tx power (46 dBm, no sleep states).
        - Basic Proportional Fair (PF) scheduling without proactive latency/URLLC prioritization.
        """
        for cell_id, cell in self.cells.items():
            cell.allocated_prbs = 273
            cell.power_state = PowerState.ACTIVE_MAX
            cell.active_tx_power_dbm = 46.0

            active_ues = list(cell.connected_ues.values())
            if not active_ues:
                cell.current_load_ratio = 0.0
                cell.throughput_mbps = 0.0
                cell.avg_latency_ms = 1.0
                cell.instantaneous_power_w = cell.compute_power_consumption(0.0)
                continue

            # Proportional Fair scheduler metric: R_i / avg_R_i
            # PRBs distributed across UEs
            prbs_per_ue = max(1, cell.allocated_prbs // len(active_ues))
            total_tp = 0.0
            total_lat = 0.0
            drops = 0

            for ue in active_ues:
                spec_eff = CQI_TABLE[ue.cqi][4]  # bps/Hz
                # 1 PRB = 12 subcarriers * 30 kHz = 360 kHz
                # Achievable rate = PRBs * 360 kHz * Spectral Efficiency
                achievable_rate_mbps = (prbs_per_ue * 360e3 * spec_eff) / 1e6
                served_rate = min(achievable_rate_mbps, ue.buffer_bytes * 8 / 1e6)
                
                ue.assigned_prbs = prbs_per_ue
                ue.served_throughput_mbps = round(served_rate, 2)
                total_tp += served_rate

                # Buffer drain & delay
                remaining_bytes = max(0.0, ue.buffer_bytes - (served_rate * 1e6 / 8))
                ue.buffer_bytes = remaining_bytes
                
                # Queue delay increases if buffer builds up
                if ue.buffer_bytes > 0:
                    ue.queue_delay_ms += (ue.buffer_bytes / (max(0.1, served_rate) * 1e6 / 8)) * 10
                else:
                    ue.queue_delay_ms = max(2.0, ue.queue_delay_ms * 0.7)

                # Packet drop if delay exceeds SLA
                if ue.queue_delay_ms > ue.max_latency_ms:
                    drops += 1
                    ue.dropped_packets += 1
                    ue.buffer_bytes *= 0.5  # Drop half queue

                total_lat += ue.queue_delay_ms

            total_used_prbs = min(cell.allocated_prbs, len(active_ues) * prbs_per_ue)
            cell.current_load_ratio = round(total_used_prbs / cell.allocated_prbs, 3)
            cell.throughput_mbps = round(total_tp, 2)
            cell.avg_latency_ms = round(total_lat / len(active_ues), 2)
            cell.packet_loss_rate = round(drops / max(1, len(active_ues)), 4)
            cell.instantaneous_power_w = round(cell.compute_power_consumption(cell.current_load_ratio), 1)
            cell.cumulative_energy_kwh += (cell.instantaneous_power_w * 0.25) / 1000.0  # 15 min interval

    def get_cell_telemetry(self) -> Dict[str, Dict]:
        """Returns snapshot of current state across all 3 cells."""
        telemetry = {}
        for cid, cell in self.cells.items():
            telemetry[cid] = {
                "name": cell.name,
                "hour": round(self.simulation_hour, 2),
                "active_ues": len(cell.connected_ues),
                "prb_quota": cell.allocated_prbs,
                "load_ratio": cell.current_load_ratio,
                "throughput_mbps": cell.throughput_mbps,
                "avg_latency_ms": cell.avg_latency_ms,
                "packet_loss_rate": cell.packet_loss_rate,
                "avg_sinr_db": cell.avg_sinr_db,
                "edge_sinr_db": cell.edge_sinr_db,
                "power_state": cell.power_state.value,
                "power_watts": cell.instantaneous_power_w,
                "tx_power_dbm": cell.active_tx_power_dbm,
                "cumulative_energy_kwh": round(cell.cumulative_energy_kwh, 2),
            }
        return telemetry
