#!/usr/bin/env python3
"""
Nokia AI-RAN Command Line Interface (CLI)
Interactive terminal interface for running 5G network simulations,
triggering scenarios, and viewing optimization telemetry.
"""

import os
import sys
import time
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from core.orchestrator import AIRANOrchestrator
from core.benchmark import BenchmarkEngine


# ANSI Color Codes
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
MAGENTA = "\033[95m"
BOLD = "\033[1m"
RESET = "\033[0m"


def print_banner():
    banner = f"""{CYAN}{BOLD}
╔══════════════════════════════════════════════════════════════════════════╗
║               NOKIA BELL LABS — AI-RAN OPTIMIZATION PLATFORM            ║
║     AI-Native Radio Silicon & Machine Learning Network Intelligence      ║
║   AI/ML ➔ Traffic Prediction ➔ Resource Optimization ➔ High Performance  ║
╚══════════════════════════════════════════════════════════════════════════╝{RESET}
"""
    print(banner)


def render_ascii_cell_card(cid: str, data: dict, ai_decisions: dict = None):
    pstate = data['power_state'].upper()
    state_color = GREEN if "ACTIVE" in pstate else (CYAN if "MICRO" in pstate else YELLOW)
    
    print(f"\n{BOLD}┌─── {data['name']} [{cid}] ───────────────────────────────────┐{RESET}")
    print(f"│ State: {state_color}{pstate:<14}{RESET} │ Load: {data['load_ratio']*100:>5.1f}% │ Active UEs: {data['active_ues']:<4} │")
    print(f"│ Throughput: {data['throughput_mbps']:>6.1f} Mbps │ Latency: {data['avg_latency_ms']:>4.1f} ms  │ Drops: {data['packet_loss_rate']*100:>4.2f}%     │")
    print(f"│ Avg SINR: {data['avg_sinr_db']:>6.1f} dB   │ Edge SINR: {data['edge_sinr_db']:>4.1f} dB │ Power: {data['power_watts']:>6.1f} W   │")
    print(f"│ Bandwidth: {data['prb_quota']:>4} PRBs     │ Tx Power: {data['tx_power_dbm']:>4.1f} dBm │ Energy: {data['cumulative_energy_kwh']:>5.2f} kWh │")

    if ai_decisions:
        # Show specific AI decisions for this cell
        spec = ai_decisions.get("spectrum_optimization", {}).get(cid, {})
        pwr = ai_decisions.get("power_optimization", {}).get(cid, {})
        cong = ai_decisions.get("capacity_congestion", {}).get(cid, {})
        
        print(f"│{CYAN} [AI-SPECTRUM]{RESET} {spec.get('action_summary', 'N/A'):<46} │")
        print(f"│{GREEN} [AI-POWER]{RESET}    {pwr.get('rationale', 'N/A')[:46]:<46} │")
        risk = cong.get('risk_level', 'OK')
        r_color = RED if risk == "CRITICAL" else (YELLOW if risk == "WARNING" else GREEN)
        print(f"│{MAGENTA} [AI-CAPACITY]{RESET} Risk: {r_color}{risk:<8}{RESET} (Sat in {cong.get('minutes_to_congestion', 'N/A')} min)          │")
    
    print(f"└─────────────────────────────────────────────────────────────┘")


def main():
    print_banner()
    print(f"{BOLD}Select Mode:{RESET}")
    print("1. Run Full 24-Hour Benchmark (Legacy RAN vs Nokia AI-RAN)")
    print("2. Run Live 10-Step Interactive Simulation with AI-RAN")
    print("3. Run Stress-Test Scenario (Rush Hour / Stadium Surge)")
    print("4. Exit")

    choice = input(f"\n{YELLOW}Enter choice (1-4, default=1): {RESET}").strip() or "1"

    if choice == "1":
        print(f"\n{CYAN}⚡ Running 24-Hour Multi-Scenario Simulation (96 intervals of 15 min)...{RESET}")
        bench = BenchmarkEngine(steps=48)
        report = bench.run_benchmark()
        score = report["summary_scorecard"]
        leg = report["legacy_kpis"]
        ai = report["ai_kpis"]

        print(f"\n{GREEN}{BOLD}═══════════════════ BENCHMARK SCORECARD ═══════════════════{RESET}")
        print(f" Throughput Uplift:          {GREEN}{BOLD}+{score['throughput_boost_pct']}%{RESET} (from {leg['avg_throughput_mbps']} to {ai['avg_throughput_mbps']} Mbps)")
        print(f" Base Station Energy Saved:  {GREEN}{BOLD}{score['energy_saved_pct']}%{RESET} ({score['kwh_saved']} kWh reduction)")
        print(f" Carbon Offset:              {GREEN}{BOLD}{score['co2_emissions_avoided_kg']} kg CO2 avoided{RESET}")
        print(f" Latency Reduction:          {GREEN}{BOLD}{score['latency_reduction_pct']}%{RESET} (p99 latency: {score['p99_latency_reduction_pct']}%)")
        print(f" Packet Drop Reduction:      {GREEN}{BOLD}{score['packet_drop_reduction_pct']}%{RESET}")
        print(f" Cell-Edge SINR Gain:        {GREEN}{BOLD}+{score['cell_edge_sinr_gain_db']} dB{RESET}")
        print(f"{GREEN}{BOLD}═══════════════════════════════════════════════════════════{RESET}\n")

    elif choice in ["2", "3"]:
        orch = AIRANOrchestrator(mode="AI_ENABLED")
        if choice == "3":
            print(f"{YELLOW}Injecting 'stadium_surge' scenario into Cell_A...{RESET}")
            orch.set_scenario("stadium_surge")

        print(f"\n{CYAN}Starting Real-Time Closed-Loop AI-RAN Steps...{RESET}")
        for step in range(5):
            rec = orch.run_step()
            hour = rec["hour"]
            print(f"\n{BOLD}════════ Time Step {step+1} (Simulation Clock: {hour:04.1f}h) ════════{RESET}")
            for cid, cdata in rec["telemetry"].items():
                render_ascii_cell_card(cid, cdata, rec.get("ai_decisions"))
            time.sleep(0.4)

    print(f"\n{CYAN}To launch the full interactive web dashboard, run:{RESET}")
    print(f"{BOLD}python3 server.py{RESET} and open your browser at {GREEN}http://localhost:8000{RESET}\n")


if __name__ == "__main__":
    main()
