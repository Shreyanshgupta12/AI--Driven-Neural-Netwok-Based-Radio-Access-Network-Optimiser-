# Nokia AI-RAN: Neural Network-Driven Radio Access Network Optimization

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100+-green.svg)](https://fastapi.tiangolo.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An end-to-end Machine Learning and 5G Radio Access Network (RAN) optimization platform inspired by **Nokia's AI-RAN** and **Predictive Operations** initiatives. 

Nokia launched the industry's first commercial AI-native RAN platform, applying real-time AI algorithms directly to radio silicon to boost spectral efficiency, lower base station power, and automate traffic operations before outages happen.

This platform implements, simulates, and visualizes the complete feedback loop:

$$\mathbf{AI/ML} \;\longrightarrow\; \mathbf{Traffic\;Prediction} \;\longrightarrow\; \mathbf{Resource\;Optimization} \;\longrightarrow\; \mathbf{Better\;Network\;Performance}$$

---

## Key Optimization Pillars

| # | Pillar | Physical Challenge | AI/ML Solution | Performance Gain |
|---|---|---|---|---|
| **1** | **Spectrum Optimization** 📡 | Limited radio frequency bands; static PRB allocation starves congested cells while idle cells waste spectrum. | Gradient-boosted demand forecasting + elastic PRB pooling (Dynamic Spectrum Sharing). | **+30% to +66% Throughput** |
| **2** | **Power Optimization** ⚡ | Base station transceivers consume up to 80% of network electricity, running at maximum power even during night lulls. | Temporal traffic prediction + Green RAN multi-level sleep (Symbol Micro-Sleep, Dynamic PA scaling, Deep Sleep). | **25% to 35% Energy Saved** (160+ kWh/day) |
| **3** | **Scheduling Optimization** 📅 | Traditional Round Robin and Proportional Fair schedulers fail to prioritize delay-critical URLLC packets, causing SLA drops. | Multi-objective AI-Native MAC scheduler balancing CQI, queue delay deadlines, and QoS weights. | **50% Latency Reduction** (URLLC &lt; 5ms) |
| **4** | **Capacity Optimization** 📊 | Cells nearing 85–100% capacity suffer buffer explosion, soaring latency, and massive dropped calls. | Predictive congestion classifier forecasting overload 15–30 min ahead + proactive Handover Margin (HOM) steering. | **38% Packet Drop Reduction** |
| **5** | **Interference Optimization** 📶 | Radio cross-talk between adjacent cells degrades SINR and throughput for cell-edge commuters. | Radio measurement learning + Coordinated Multi-Point (CoMP) power down-regulation and Massive MIMO spatial nulling. | **+0.5 to +3.5 dB Cell-Edge SINR** |
| **6** | **Traffic Optimization** 🚦 | Diurnal rush hour waves and unexpected flash crowds (stadium concerts) destabilize network capacity. | Supervised sequence models forecasting cell load + mobility load balancing (MLB) across carrier frequencies. | **98.2% Forecast Accuracy (R²)** |

---

## System Architecture

```
                                      ┌─────────────────────────────────────────┐
                                      │        5G NR Multi-Cell Network         │
                                      │  Cell A (Urban Hub, n78 3.5 GHz)        │
                                      │  Cell B (Suburban Residential, n78)     │
                                      │  Cell C (Industrial Park, n28 700 MHz)  │
                                      └────────────────────┬────────────────────┘
                                                           │ RSRP / SINR / Queue Telemetry
                                                           ▼
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                             AI-RAN CLOSED-LOOP ORCHESTRATOR                                           │
│                                                                                                                       │
│  1. Traffic Demand Predictor (LSTM / GBR) ──► Forecasts PRB demand & active UEs for 15m & 60m horizons               │
│  2. Capacity Guard & Steering Engine      ──► Proactively shifts edge UEs before 85% congestion threshold           │
│  3. Spectrum & PRB Dynamic Allocator      ──► Pools 819 PRBs and assigns elastic quotas to high-demand cells          │
│  4. Energy Saving Controller (Green RAN)  ──► Selects Micro-Sleep / Deep-Sleep / Dynamic PA based on QoS guardrails  │
│  5. Interference Mitigator (CoMP)         ──► Applies downlink power trimming & spatial nulling on neighbor cells    │
│  6. AI-Native QoS MAC Scheduler          ──► Subframe PRB assignments prioritizing URLLC delay and CQI gains        │
└──────────────────────────────────────────────────────────┬────────────────────────────────────────────────────────────┘
                                                           │
                                   ┌───────────────────────┴───────────────────────┐
                                   ▼                                               ▼
                    ┌──────────────────────────────┐                ┌──────────────────────────────┐
                    │    Interactive Web UI        │                │    CLI & Benchmark Runner    │
                    │  - 2D Canvas Topology Map    │                │  - Side-by-side 24h simulation│
                    │  - 6 Deep-Dive Pillar Views  │                │  - Colored ASCII Scorecard   │
                    │  - Interview & Explainer Tab │                │  - Automated Unit Tests      │
                    └──────────────────────────────┘                └──────────────────────────────┘
```

---

## Detailed Explanations of the 6 Pillars

### 1. Spectrum Optimization 📡
* **The Concept**: Spectrum is the finite radio frequency bandwidth (e.g. 100 MHz in 5G Band n78 yielding 273 PRBs per cell). In legacy networks, spectrum is partitioned statically (33% to each cell). When Downtown Cell A experiences 90% load and Suburban Cell B has only 20% load, Cell A drops packets while Cell B's allocated spectrum sits completely idle.
* **How ML Solves It**: The `SpectrumOptimizer` uses predictive demand weights to dynamically pool all 819 PRBs across the cluster. Cell A is allocated up to 380 PRBs during rush hour, while maintaining a guaranteed minimum (50 PRBs) in idle cells to ensure zero starvation.
* **Interview Answer**:
  > *"ML learns traffic demand and radio conditions to predict future spectrum requirements. The network dynamically allocates spectrum and PRB resources from an elastic pool to cells with the highest demand, maximizing spectral efficiency and eliminating congestion."*

---

### 2. Power & Energy Optimization ⚡
* **The Concept**: Power amplifiers (PAs) and radio transceivers (64T64R Massive MIMO) consume thousands of Watts even when transmitting empty subframes.
* **How ML Solves It**: The `EnergySaver` implements the 3GPP EARTH energy model with 4 operating states:
  1. `ACTIVE_MAX` (46 dBm, full throughput capacity).
  2. `ACTIVE_DYNAMIC_PA` (scales PA bias down by 2.5 dBm when users are close to the tower).
  3. `MICRO_SLEEP` (mutes power amplifiers during empty symbols/slots, saving 35–45% of energy).
  4. `DEEP_SLEEP` (transits secondary carriers to standby during night lulls 02:00–05:00, saving 75–80% power).
  * *SLA Guardrail*: Deep sleep is strictly prohibited if any active mission-critical URLLC sessions are detected.
* **Interview Answer**:
  > *"ML predicts traffic demand and network load, allowing the RAN to dynamically adjust transmission power or place underutilized resources into micro-sleep or deep-sleep states while strictly guaranteeing quality of service."*

---

### 3. Scheduling Optimization 📅
* **The Concept**: In every 1 ms transmission time interval (TTI), the base station must decide which users receive PRBs. Round Robin ignores channel quality; Proportional Fair balances throughput and fairness but has no concept of packet delay deadlines.
* **How ML Solves It**: The `IntelligentScheduler` scores each user using an AI utility function:
  $$\text{Score}_i = w_1 \cdot \text{CQI}_i + w_2 \cdot \left(\frac{\text{QueueDelay}_i}{\text{MaxLatency}_i}\right)^\gamma + w_3 \cdot \text{QoS\_Weight}_i + w_4 \cdot \ln(1 + \text{Buffer}_i)$$
  As a URLLC packet approaches its 5–8 ms deadline, the delay exponent term spikes, granting immediate PRB allocation to flush the queue before SLA expiration.
* **Interview Answer**:
  > *"ML enhances scheduling by jointly evaluating channel quality, traffic demand, delay deadlines, and QoS requirements, making optimal sub-millisecond resource assignments that slash latency and eliminate SLA violations."*

---

### 4. Capacity Optimization & Congestion Guard 📊
* **The Concept**: When a cell approaches 85–100% capacity, queue buffers overflow and packet drop rates escalate exponentially.
* **How ML Solves It**: The `CapacityGuard` computes the derivative of user influx $d(\text{UE})/dt$ and projects time-to-saturation. If a cell is predicted to exceed 85% within 20 minutes, it automatically shifts 3GPP A3 Handover Margins (HOM) and Cell Individual Offsets (CIO):
  $$\text{RSRP}_{\text{target}} + \text{CIO}_{\text{target}} > \text{RSRP}_{\text{serving}} + \text{HOM}$$
  Boundary users are steered to adjacent underutilized cells before packet drop spikes occur.
* **Interview Answer**:
  > *"ML predicts future network load and capacity exhaustion, allowing operators to proactively allocate resources or redistribute traffic to adjacent cells before congestion and dropped calls occur."*

---

### 5. Interference Optimization & CoMP 📶
* **The Concept**: Boundary users receive desired signals from their serving cell along with unwanted interference from neighboring base stations transmitting at full power.
* **How ML Solves It**: The `InterferenceMitigator` processes UE RSRP/RSRQ/SINR measurement reports. It commands neighboring cells with light load to trim transmission power on overlapping subbands and uses Massive MIMO 64T64R spatial degrees of freedom to steer nulls toward victim users, elevating cell-edge 5th percentile SINR.
* **Interview Answer**:
  > *"ML learns interference patterns from radio measurements and optimizes transmission power, beam configurations, and resource coordination to suppress inter-cell interference and elevate cell-edge throughput."*

---

### 6. Traffic Optimization & Demand Forecasting 🚦
* **The Concept**: Cellular traffic shifts continuously across diurnal curves, rush hours, weekend patterns, and flash crowd events (stadium concerts).
* **How ML Solves It**: The `TrafficPredictor` uses an ensemble of gradient-boosted temporal sequence models with cyclical features $(\sin(2\pi h/24), \cos(2\pi h/24))$, day-of-week, and moving variance to forecast PRB requirements and detect flash crowd anomalies.
* **Interview Answer**:
  > *"ML forecasts multi-cell traffic dynamics from historical patterns and real-time trends, enabling proactive traffic steering and dynamic load balancing across carrier frequencies and neighboring cells."*

---

## 24-Hour Benchmark: Legacy 5G RAN vs Nokia AI-RAN

Simulated across 96 discrete 15-minute time steps with diurnal traffic, rush-hour congestion, stadium surge, and rain fading:

```
═══════════════════════ BENCHMARK SCORECARD ═══════════════════════
 Throughput Uplift:          +66.3%  (from 142.6 to 237.2 Mbps)
 Base Station Energy Saved:  30.9%   (204.8 kWh saved per cluster)
 Carbon Offset:              92.2 kg CO2 avoided per cluster/day
 Latency Reduction:          50.8%   (p99 latency reduced by 24%)
 Packet Drop Reduction:      38.5%   (proactive congestion steering)
 Cell-Edge SINR Gain:        +0.5 to +3.5 dB (spatial nulling)
═══════════════════════════════════════════════════════════════════
```

---

## Installation & Getting Started

### 1. Prerequisites
- Python 3.10+
- Modern Web Browser (Chrome, Safari, Edge, Firefox)

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Launch the Interactive Web Dashboard
```bash
python3 server.py
```
Open your browser at **[http://localhost:8080](http://localhost:8080)**.

The web application includes:
* **Live RAN Control Room**: Real-time 2D Canvas topology map showing Cells A, B, and C, active Massive MIMO beam projections, connected UEs (color-coded by eMBB, URLLC, mMTC), and dynamic handover steering arcs.
* **6 Deep-Dive Pillar Panels**: Live interactive charts for Spectrum, Power, Scheduling, Capacity, Interference, and Traffic.
* **Scenario Injection**: Test "Morning Rush Hour", "Stadium Flash Crowd", "Night Lull", and "Severe Rain Fading" with a single click.
* **Interview & Master Guide**: Built-in flashcards with conceptual explanations, math, and copy-ready interview answers.

---

### 4. Run via Terminal CLI
For headless environments or quick terminal inspections:
```bash
python3 run_cli.py
```
Select `1` to execute the full 24-hour benchmark or `2` for real-time live simulation steps.

---

### 5. Run Automated Tests
```bash
python3 -m unittest discover -s tests -p "test_*.py"
```
All unit and integration tests pass in &lt; 1 second.

---

## Repository Structure

```
.
├── core/
│   ├── simulator/
│   │   ├── __init__.py
│   │   └── network_sim.py         # 5G NR physical layer simulator (3GPP UMa, CQI, SINR, PRBs, EARTH power model)
│   ├── models/
│   │   ├── __init__.py
│   │   ├── traffic_predictor.py   # Pillar 6: ML demand forecasting & anomaly detection
│   │   ├── spectrum_optimizer.py  # Pillar 1: Dynamic spectrum & PRB elastic pool allocator
│   │   ├── energy_saver.py        # Pillar 2: Green RAN multi-level sleep & dynamic PA controller
│   │   ├── scheduler.py           # Pillar 3: AI-Native QoS & latency-deadline MAC scheduler
│   │   ├── capacity_guard.py      # Pillar 4: Congestion prediction & proactive traffic steering
│   │   └── interference_mitigator.py # Pillar 5: CoMP interference coordination & beam nulling
│   ├── orchestrator.py            # Unified closed-loop controller coordinating simulator & 6 pillars
│   └── benchmark.py               # Dual-track 24h benchmark engine (Legacy vs AI-RAN)
├── tests/
│   └── test_sim_and_models.py     # Unit test suite covering all modules
├── web/
│   ├── index.html                 # Modern cyber-aesthetic dashboard HTML5
│   ├── app.css                    # Glassmorphism design system & cyberpunk palette
│   └── app.js                     # Canvas 2D topology renderer, Chart.js metrics, and REST client
├── server.py                      # FastAPI REST server & static web server (port 8080)
├── run_cli.py                     # Standalone interactive CLI runner
├── requirements.txt               # Dependencies (PyTorch, Scikit-Learn, FastAPI, NumPy, Pandas)
└── README.md                      # Complete documentation & interview guide
```

---

## Telecom Standards & 3GPP Specifications Referenced
* **3GPP TS 38.214**: Physical layer procedures for data (CQI Table 5.2.2.1-2, 64QAM/256QAM spectral efficiencies).
* **3GPP TR 38.901**: Study on channel model for frequencies from 0.5 to 100 GHz (Urban Macro Path Loss & Shadowing).
* **3GPP TS 38.331**: Radio Resource Control (RRC) protocol specification (Event A3 Handover Margin & Cell Individual Offset).
* **EARTH Project Energy Model**: Energy Aware Radio and NeTwork Technologies (base station power consumption breakdown).
* **O-RAN Alliance Working Group 2 / 3**: Non-Real-Time and Near-Real-Time RAN Intelligent Controllers (Non-RT RIC / Near-RT RIC & rApps / xApps).

---

## License
MIT License. Built for telecommunications engineers, machine learning practitioners, and AI-RAN researchers.
